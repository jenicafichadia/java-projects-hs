// Jenica Fichadia and Jennifer Lam pd2

public  class Phrase {
   private String currentPhrase;
   
   public Phrase (String p) { 
      currentPhrase = p; 
   }
   
   public int findNthOccurrence(String str, int n){
      int count = 0;
      int c = -1;
      int length = str.length()-1;
      
      while(c<currentPhrase.length()-1 && count<n){
         c++;
         boolean tf = true;
         for(int i=0; i<length; i++){
            if(c+i+1<=currentPhrase.length()){
               if(!(currentPhrase.substring(c+i, c+i+1).equals(str.substring(i,i+1)))){ tf = false; }
            }
         }
         if(tf==true){ count++; } 
      }
      
      if (count!=n){ return -1; }
      return c;   
      
   }
   
   public void replaceNthOccurrence (String str, int n, String rep){
      int o = findNthOccurrence(str, n);
      String s = "";
      if(o!=-1){
         s+=currentPhrase.substring(0 , o) + rep + currentPhrase.substring(o+str.length());
         currentPhrase = s;         
      }
      
   }    
   
   public int findLastOccurrence(String str){
      int index = -1;
      boolean tf = false;
      int i = 1;
      while(tf!=true){
         if(i==1 && findNthOccurrence(str, i)==-1){
            index = -1;
            tf=true;
         }
         else if(i!=1 && findNthOccurrence(str, i)==-1){
            index = i-1;
            tf=true;
         }
         else{
            i++;
         }
      }
      if(index!=-1)
         return findNthOccurrence(str, index);
      return -1;
      
   }
   
   public String toString(){
      return currentPhrase;
   }
   
   public static void main (String[] args){
      Phrase p1= new Phrase("A cat ate late");
      Phrase p3= new Phrase("A cat ate late"); 	
      Phrase p4= new Phrase("A cat ate late");     
      System.out.println( p1.findNthOccurrence("at", 1)); // outputs 3      
      System.out.println( p1.findNthOccurrence("at", 3)); // outputs 11    
      System.out.println( p1.findNthOccurrence("at", 8)); // outputs -1    
      System.out.println( p1.findNthOccurrence("in", 1)); // outputs -1
      System.out.println();
      
      System.out.println( p1.findLastOccurrence("at")); // outputs 11      
      System.out.println( p1.findLastOccurrence("cat")); // outputs 2    
      System.out.println( p1.findLastOccurrence("bat")); // outputs -1  
      System.out.println();
      
      p1.replaceNthOccurrence("at", 1, "rane"); 
      System.out.println(p1.toString());// outputs a crane ate late
      p3.replaceNthOccurrence("at", 6, "xx"); 
      System.out.println(p3.toString());// outputs a cat ate late
      p4.replaceNthOccurrence("bat", 2, "xx"); 
      System.out.println(p4.toString());// outputs a cat ate late   
      System.out.println(); 
      System.out.println();
  
      Phrase p2= new Phrase("aaaa");
      Phrase p5= new Phrase("aaaa");
      System.out.println( p2.findNthOccurrence("aa", 2)); // outputs 1
      System.out.println();
      p2.replaceNthOccurrence("aa", 1, "xx"); 
      System.out.println(p2.toString());// outputs xxaa
      p5.replaceNthOccurrence("aa", 2, "bbb"); 
      System.out.println(p5.toString());// outputs abbba
      
      
     

   }



}