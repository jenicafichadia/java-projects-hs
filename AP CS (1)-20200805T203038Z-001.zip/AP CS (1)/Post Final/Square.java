// Jenica Fichadia and Jennifer Lam pd2

public class Square {
   private int num;
   private String color;
   
   public Square(int n, String c){
      num=n;
      color=c;
   }
   
   public int getNum(){
      return num;
   }
   
   public void setNum(int n){
      num = n;
   }
   
   public String getColor(){
      return color;
   }
   
   public void setColor(String c){
      color = c;
   }
   
   
}