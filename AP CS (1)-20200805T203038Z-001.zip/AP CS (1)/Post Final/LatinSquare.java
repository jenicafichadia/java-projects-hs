// Jenica Fichadia and Jennifer Lam pd2
import java.util.*;

public class LatinSquare {
   
   public static int[] getColumn (int [][]arr2D, int c){
      int[] arr = new int [arr2D.length];
      
      for(int i=0; i<arr2D.length; i++){
         arr[i] = arr2D[i][c];
      }
      return arr;
   }
   
   public static boolean hasAllValues (int []arr1, int []arr2){
      int count = 0;
      for(int i=0; i<arr1.length; i++){
         for(int j=0; j<arr2.length; j++){
            if(arr1[i] == arr2[j]) 
               count++;
         }
      }
      return (count == arr2.length);

   }
   
   public static boolean containsDuplicates(int [] arr){
      for(int i=0; i<arr.length; i++){
         for(int j=i+1; j<arr.length; j++){
            if(arr[i]==arr[j]){
               return true;
            }
         }
      }
      return false;
   }
   
   public static boolean isLatin(int [][] square){
      if(containsDuplicates(square[0]) == true){
         return false;
      }
      for(int r=1; r<square.length; r++){
         if(hasAllValues(square[0], square[r]) == false){
            return false;
         }        
      }
      for(int c=0; c<square.length; c++){
         if(hasAllValues(square[0], getColumn(square, c)) == false){
            return false;
         }
      }
      return true;
      
   }
   
   public static void main(String[] args){
      int[][] box = {{3, 2, 5}, {6, 4, 7}, {9, 9, 9}};
      int[][] latSquare = {{1, 2, 3}, {2, 3, 1}, {3, 1, 2}};
      
      System.out.println("Box 1");
      for (int i = 0; i < box.length; i++){
         System.out.println(Arrays.toString(box[i]));
      }
      System.out.println("The middle column is " + Arrays.toString(getColumn(box, 1)));
      System.out.println("The first row has all values of first column {t/f): " + hasAllValues(box[0], getColumn(box,0)));
      System.out.println("The first row contains duplicates (t/f): " + containsDuplicates(box[0]));
      System.out.println("The last row contains duplicates (t/f): " + containsDuplicates(box[2]));
      System.out.println("Box 1 is a latin square (t/f): " + isLatin(box));
      System.out.println();
      
      System.out.println("Box 2");
      for (int i = 0; i < latSquare.length; i++){
         System.out.println(Arrays.toString(latSquare[i]));
      }
      System.out.println("The middle column is " + Arrays.toString(getColumn(latSquare, 1)));
      System.out.println("The first row has all values of first column (t/f): " + hasAllValues(latSquare[0], getColumn(latSquare,0)));
      System.out.println("The second row has all values of third column (t/f): " + hasAllValues(latSquare[1], getColumn(latSquare,2)));
      System.out.println("The first row contains duplicates (t/f): " + containsDuplicates(latSquare[0]));
      System.out.println("The last row contains duplicates (t/f): " + containsDuplicates(latSquare[2]));
      System.out.println("Box 2 is a latin square (t/f): " + isLatin(latSquare));
   
   }




}