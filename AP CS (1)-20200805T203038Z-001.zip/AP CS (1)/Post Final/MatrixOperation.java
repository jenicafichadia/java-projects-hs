// Jenica Fichadia and Jennifer Lam pd2
import java.text.DecimalFormat;
public class MatrixOperation{
   
   public MatrixOperation(){}
   
   public boolean sizeCheck (double [][] ar1, double [][] ar2){
      return ar1.length == ar2.length && ar1[0].length == ar2[0].length;      
   }
   
   public double [][] scalarMultiplication(double [][] ar, double sc){
      if(ar.length>0){
         double[][] arr = new double [ar.length][ar[0].length];
         for(int r = 0; r<ar.length; r++){
            for(int c = 0; c<ar[r].length; c++){
               arr[r][c] = sc*ar[r][c];
            }
         }
         return arr;
      }
      
      throw new NullPointerException("no elements");     
   } 
   
   private double[][] Operate(double[][] ar1, double[][] ar2, String op){
      double[][] arr = new double [ar1.length][ar1[0].length];
         for(int r = 0; r<ar1.length; r++){
            for(int c = 0; c<ar1[r].length; c++){
               if(op.equals("+")){  arr[r][c] = ar1[r][c] + ar2[r][c];  }
               else {  arr[r][c] = ar1[r][c] - ar2[r][c];  }
            }
         }
         
         return arr;
   }
   
   public double[][] addMatrix(double[][] ar1, double[][] ar2){
      boolean tf = true;
      try{
         if(sizeCheck(ar1, ar2) == false){ 
            tf = false; 
            throw new NullPointerException("Operation cannot be performed");  
         }
      }catch (NullPointerException e) { 
         System.out.println("Operation cannot be performed"); 
      }
           
      if(tf == false)  return null;
      return Operate(ar1, ar2, "+");  
   }
   
   public double[][] subtractMatrix(double[][] ar1, double[][] ar2){
      boolean tf = true;
      try{
         if(sizeCheck(ar1, ar2) == false){ 
            tf = false; 
            throw new NullPointerException("Operation cannot be performed");  
         }
      }catch (NullPointerException e) { 
         System.out.println("Operation cannot be performed"); 
      }
           
      if(tf == false)  return null;
      return Operate(ar1, ar2, "-");
          
   }
   
   public double[][] multiplyMatrix (double[][] ar1, double[][] ar2){
      boolean tf = true;
      try{
         if(ar1[0].length != ar2.length){
            tf = false;
            throw new NullPointerException("Operation cannot be performed");
         }
      }catch (NullPointerException e){
         System.out.println("Operation cannot be performed");
      }
      if(tf == false)  return null;

      double[][] arr = new double [ar1.length][ar2[0].length];
      for (int c2 = 0; c2 < ar2[0].length; c2++){
         for (int r1 = 0; r1 < ar1.length; r1++){
            int sum = 0;
            for (int r2 = 0; r2 < ar2.length; r2++){
               sum+=ar1[r1][r2]*ar2[r2][c2];
            }
            arr[r1][c2] = sum;
         }
      }
      return arr;
           
      
   }
   
   public static void printMatrix (double[][] arr){
      if(arr == null){  System.out.println("Matrix cannot be printed");  }
      else{
         DecimalFormat num = new DecimalFormat("#,####,###,##0.0#");
         String s = "";
         for(int r = 0; r<arr.length; r++){
            for(int c=0; c<arr[0].length; c++){
               s += num.format(arr[r][c]) + "\t";
            }
            s+= "\n";
         }
         System.out.println(s);
      }

   }
   

}