// Jenica Fichadia and Jennifer Lam pd 2
import java.util.Scanner;

class CheckingTester{ 
   public static void main(String[] args){ 
      Scanner input = new Scanner(System.in);
      //input stuff
      CheckingAccount check1 = new CheckingAccount();
      double bal =0;
      do{
         System.out.print("Please enter the starting balance -->  ");
         bal = input.nextDouble();
         CheckingAccount check =  new CheckingAccount(bal, 123);
         if(bal>0){  check1 = check;  }
         System.out.println();
      } while (bal<0);
      
      System.out.println();
      System.out.println("Account opened with balance of " + check1.getBalance());
      System.out.println();
      
      double deposit =0;
      do{
         System.out.print("Please enter the amount to deposit -->  ");
         deposit = input.nextDouble();
         check1.deposit(deposit); 
         System.out.println(); 
      } while (deposit<0);
      
      System.out.println();
      System.out.println("Deposit made. Current account balance =  " + check1.getBalance());
      System.out.println();
      
      double withdraw = 0;
      do{
         System.out.print("Please enter the amount to withdraw -->  ");
         withdraw = input.nextDouble();
         check1.withdraw(withdraw);  
         System.out.println();
      } while (withdraw<0 || withdraw > check1.getBalance());
      
      System.out.println();
      System.out.println("Withdrawal made. Current account balance =  " + check1.getBalance());
      System.out.println();
      
      System.out.println("Thank you for using ErrorFreeChecking...goodbye!");
      
      
      
      
      
      
      /*
      CheckingAccount checking =  new CheckingAccount(1000.0, 122); 
      double INTEREST_RATE = 2.5; 
      double interest; 
      interest = checking.getBalance() * INTEREST_RATE / 100; 
      checking.deposit(interest); 
      System.out.println("Balance after year 1 is $" + checking.getBalance()); 
      interest = checking.getBalance() * INTEREST_RATE / 100; 
      checking.deposit(interest); 
      System.out.println("Balance after year 2 is $" + checking.getBalance()); */
   } 
} 
