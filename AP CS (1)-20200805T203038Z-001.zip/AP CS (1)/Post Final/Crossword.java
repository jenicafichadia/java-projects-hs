//Jenica Fichadia pd2

public class Crossword {
   private int[][] squares;
   
   public Crossword(boolean[][] blackSquares){
      squares = new int[blackSquares.length][blackSquares[0].length];
      int num = 1;
      for (int r = 0; r < squares.length; r++){
         for (int c = 0; c < squares[r].length; c++){
            if (this.toBeLabeled(blackSquares, r, c) == true){
               squares[r][c] = num;
               num++;
            }
            if (blackSquares[r][c] == true){
               squares[r][c] = -1;
            }
         }
      }
   }
   
   public boolean toBeLabeled(boolean[][] blackSquares, int r, int c){
      if (blackSquares[r][c] == false){ //if white
         if (r == 0){ //first row
            return true;
         }
         else{
            if (c == 0){ //first column
               return true;
            }
            else{
               return blackSquares[r-1][c] || blackSquares[r][c-1];
            }
         }
      }
      else{
         return false;
      }            
   }//end of toBeLabeled
   
   
   public String print(){
      String end = "";
      for(int r=0; r<squares.length; r++){
         for(int c=0; c<squares[r].length;c++){
            if(squares[r][c]==-1){
               end+="*\t";
            }
            else if(squares[r][c]==0){
               end+="_\t";
            }
            else{
               end+=squares[r][c] + "\t";
            }
               
            if(c==squares[r].length-1){
               end+="\n";
            }
            
         
         }
      }
      return end;
   }//end of print()
   
      



}