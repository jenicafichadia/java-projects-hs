//Jenica Fichadia and Jennifer Lam pd 2

public class CrosswordTester {
   public static void main(String[] args){
      boolean[][] blackSquares = new boolean [7][9];
      blackSquares[0][0] = true;
      blackSquares[0][3] = true;
      blackSquares[0][4] = true;
      blackSquares[0][5] = true;
      blackSquares[1][4] = true;
      blackSquares[2][6] = true;
      blackSquares[2][7] = true;
      blackSquares[2][8] = true;
      blackSquares[3][2] = true;
      blackSquares[3][6] = true;
      blackSquares[4][0] = true;
      blackSquares[4][1] = true;
      blackSquares[4][2] = true;
      blackSquares[5][4] = true;
      blackSquares[6][3] = true;
      blackSquares[6][4] = true;
      blackSquares[6][5] = true;
      blackSquares[6][8] = true;
      
      Crossword c = new Crossword(blackSquares);
      System.out.println(c.print());
   }
}