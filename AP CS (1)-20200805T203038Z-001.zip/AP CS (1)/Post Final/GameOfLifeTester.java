// Jenica Fichadia pd 2
import java.io.*;
import java.util.Scanner;

public class GameOfLifeTester{
   public static void main (String[] args)throws FileNotFoundException{
      Scanner reader = new Scanner(new File("life100.txt"));
      Scanner input = new Scanner(System.in);
      
      GameOfLife game = new GameOfLife("life100.txt");
      
      System.out.println( game.toString() );
      System.out.println("cells in row 3: " + game.getCellsInRow(3));
      System.out.println("cells in column 3: " + game.getCellsInCol(3));
      System.out.println("cells total is " + game.getTotalCells());
      
      System.out.print("number of generations to advance ");
      int b = input.nextInt();
      for(int i=1; i<=b; i++){
         game.nextGen();
      }
   }
}