// Jenica Fichadia pd2
import java.io.*;
import java.util.Scanner;

public class GameOfLife{
   public static final int SIZE = 5;
   private int[][] grid;
   public GameOfLife(String str) throws FileNotFoundException{
       grid = new int[SIZE][SIZE];
      Scanner reader = new Scanner(new File(str));
      while(reader.hasNext()){
         int row = reader.nextInt();
         int col = reader.nextInt();
         grid[row][col] = 1;
      }
   }
   
   public int numOfNeighbours(int r, int c){// last row left
      int count = 0;
      int[] s = {grid[r-1][c], grid[r-1][c-1], grid[r][c-1], grid[r+1][c-1], grid[r+1][c], grid[r+1][c+1], grid[r][c+1], grid[r-1][c+1]};
      for(int i=0; i<=8; i++){
         if(i<3){
            if(!(r-1<0)){
            
               for(int j =0; j<3; j++){
                  if(j==0 && !(c-1<0){
                     if(grid[r][c-1]==1){  count++;  }
                  }
                  else if(j==1 && 
               }
      }
      if(r==0){
         if(grid[r+1][c]==1){  count++; }
         if(c==0){
            if(grid[r+1][c+1]==1){  count++; }
            if(grid[r][c+1]==1){  count++; }
         }
         else if(c==SIZE-1){
            if(grid[r+1][c-1]==1){  count++; }
            if(grid[r][c-1]==1){  count++; }
         }
         else{
            if(grid[r+1][c+1]==1){  count++; }
            if(grid[r][c+1]==1){  count++; }
            if(grid[r+1][c-1]==1){  count++; }
            if(grid[r][c-1]==1){  count++; }
         }
      }
      else if(r==SIZE-1){
         if(grid[r-1][c]==1){  count++; }
         if(c==0){
            if(grid[r-1][c+1]==1){  count++; }
            if(grid[r][c+1]==1){  count++; }
         }
         else if(c==SIZE-1){
            if(grid[r-1][c+1]==1){  count++; }
            if(grid[r][c-1]==1){  count++; }
         }
         else{
            if(grid[r-1][c+1]==1){  count++; }
            if(grid[r][c+1]==1){  count++; }
            if(grid[r-1][c+1]==1){  count++; }
            if(grid[r][c-1]==1){  count++; } 
         }
      }
      if(c==0){
         if(grid[r+1][c]==1){  count++; }
         if(grid[r+1][c+1]==1){  count++; }
         if(grid[r][c+1]==1){  count++; }
         if(grid[r][c+1]==1){  count++; }
         if(grid[r-1][c+1]==1){  count++; } 
         if(grid[r-1][c]==1){  count++; }
         if(grid[r][c-1]==1){  count++; }
      }
      if(c==SIZE-1){
      
      }
      else{
         if(grid[r+1][c]==1){  count++; }
         if(grid[r+1][c+1]==1){  count++; }
         if(grid[r][c+1]==1){  count++; }
         if(grid[r][c+1]==1){  count++; }
         if(grid[r-1][c+1]==1){  count++; } 
         if(grid[r-1][c]==1){  count++; }
         if(grid[r-1][c-1]==1){  count++; }
         if(grid[r][c-1]==1){  count++; }
      }

      return count;      
   }
   
   public int getCellsInRow (int r){
      int count = 0;
      for(int c = 0; c<grid[r].length; c++){
         if(grid[r][c]==1){  count++; }
      }
      return count;
   }
   
   public int getCellsInCol (int c){
      int count = 0;
      for(int r = 0; r<grid.length; r++){
         if(grid[r][c]==1){  count++; }
      }
      return count;
   }
   
   public int getTotalCells(){
      int count =0;
      for(int r = 0; r<grid.length; r++){
         for(int c = 0; c<grid[r].length; c++){
            if(grid[r][c]==1){  count++; }
         }
      }
      return count;
   }
   
   public void nextGen(){
      int[][] temp = new int[grid.length][grid[0].length];
      for(int r = 0; r<grid.length; r++){
         for(int c = 0; c<grid[r].length; c++){
            if(numOfNeighbours(r, c) != 2 || numOfNeighbours(r, c) != 3){ temp[r][c] = 0;  }
            else if(numOfNeighbours(r, c) == 2){  temp[r][c] = grid[r][c];  }
            else{  temp[r][c] = 1;  }
         }
      }
      grid = temp;

   }
   
   
   
   public String toString (){
      String s = "";
      for(int r = 0; r<grid.length; r++){
         for(int c = 0; c<grid[r].length; c++){
            s+= grid[r][c] + " ";
         }
         s+="\n";
      }
      return s;
   }
   
   
   
   
   

}
