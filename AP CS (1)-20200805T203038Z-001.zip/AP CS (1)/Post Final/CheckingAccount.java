// Jenica Fichadia and Jennifer Lam pd2

public class CheckingAccount{ 
   private double myBalance; 
   private int myAccountNumber; 

   public CheckingAccount(){ 
      myBalance = 0.0; 
      myAccountNumber = 0; 
   } 
   public CheckingAccount(double initialBalance, int acctNum){ 
      try{
         if(initialBalance < 0){  throw new IllegalArgumentException("Negative Balance");  }
      }
      catch(IllegalArgumentException e){
         System.out.println("Error CheckingAccount: negative initial balance");
      }
      myBalance = initialBalance; 
      myAccountNumber = acctNum; 
   } 

   public double getBalance(){ 
      return myBalance; 
   } 

   public void deposit(double amount){ 
      boolean tf = false;
      try{
         if(amount<0){  throw new IllegalArgumentException("Negative Deposit");  }
      }
      catch(IllegalArgumentException e){
         tf = true;
         System.out.println("Error deposit: negative amount");
      }
      if (tf == false) myBalance += amount; 
   } 
   public void withdraw(double amount){
      boolean tf = false;
      try{
         if ((myBalance-amount)<0 || amount<0){ throw new IllegalArgumentException("You're Broke");  }
      }
      catch(IllegalArgumentException e){
         tf = true;
         System.out.println("Error withdraw: illegal amount");
      }
      if (tf == false) myBalance-=amount;      
   } 
   
   
   
} 

