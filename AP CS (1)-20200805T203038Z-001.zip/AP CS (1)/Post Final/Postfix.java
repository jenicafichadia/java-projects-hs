//Jenica Fichadia and Jennifer Lam pd2

import java.util.*;
public class Postfix {

   public static ArrayList<String> getList(String postfix) {
      String[] temp = postfix.split(" ");
      ArrayList<String> split = new ArrayList<String>();
      for(int i=0; i<temp.length; i++){
         split.add(temp[i]);
      }
      return split;
   }   
   public static int getNextOperatorIndex(ArrayList<String> postfixList) {
      boolean tf = false;
      String s = "";
      int n = -1;
      for(int i=0; i<postfixList.size(); i++){
         s = postfixList.get(i);
         if(tf == false && (s.equals("*") || s.equals("+"))){
            n = i;
            tf = true;
         }         
      }
      return n;
   }
     
   public static int evaluate(String postfix) {
      ArrayList<String> list = getList(postfix);
      ArrayList<Integer> num = new ArrayList<Integer>();
      ArrayList<String> ops = new ArrayList<String>();

      if(getNextOperatorIndex(list) == -1){
         throw new NoSuchElementException("No operators");
      }
      
      for(int i=0; i<list.size(); i++){
         int n = getNextOperatorIndex(list);
         if (n!=-1){
            ops.add(list.get(n));
            list.remove(n);
            i--;
         }
      }// initialized ops

         


         for(int i=0; i<list.size(); i++){
            num.add(Integer.parseInt(list.get(i)));
         }// initialzed num
         while(ops.size()>0){
            for(int i=0; i<ops.size(); i++){
               if(ops.get(i).equals("*")){ // multiplication
                  int n = num.get(i) * num.get(i+1);
                  num.set(i, n);
                  num.remove(i+1);
                  ops.remove(i);
                  i--;
               }
            }
            if(ops.size()>0){  
               for(int i=0; i<ops.size(); i++){
                  if(ops.get(i).equals("+")){ // addition
                     int n = num.get(i) + num.get(i+1);
                     num.set(i, n);
                     num.remove(i+1);
                     ops.remove(i);
                     i--;
                  }
               } 
            } 
         }     
         int n = num.get(0);
         return n;      

   }
   
   public static void main(String[] args){
      String eq1 = "3 * 4 + 5 * 2 + 8";
      String eq2 = "1 + 2 * 3 + 5 * 3 * 6";
      String eq3 = "1 + 2";
      String none = "1 3 5";
      ArrayList<String> e1 = getList(eq1);
      ArrayList<String> e2 = getList(eq2);
      ArrayList<String> e3 = getList(eq3);
      ArrayList<String> n = getList(none);
      
      
      //eq1
      System.out.println(eq1);
      System.out.println("eq1 array list: " + e1.toString());
      System.out.println("The first operation is at: " + getNextOperatorIndex(e1));
      System.out.println("Evaluation: " + evaluate(eq1));
      
      System.out.println();
      //eq2
      System.out.println(eq2);
      System.out.println("eq2 array list: " + e2.toString());
      System.out.println("The first operation is at: " + getNextOperatorIndex(e2));
      System.out.println("Evaluation: " + evaluate(eq2));
      
      
      System.out.println();
      //eq3
      System.out.println(eq3);
      System.out.println("eq3 array list: " + e3.toString());
      System.out.println("The first operation is at: " + getNextOperatorIndex(e3));
      System.out.println("Evaluation: " + evaluate(eq3));
      
      System.out.println();
      //none
      System.out.println(none);
      System.out.println("eq3 array list: " + n.toString());
      System.out.println("The first operation is at: " + getNextOperatorIndex(n));
      System.out.println("Evaluation: " + evaluate(none));
   }
      
   
   
}

