// Jenica Fichadia and Jennifer Lam pd2
import java.util.Arrays;

public class FractionChecker{
   public static void main(String[] args){
      int n, d;
      Fraction[] f = new Fraction [20];
      for (int j= 0; j<20; j++){
         n = (int)(Math.random()*20);
         d = (int)(Math.random()*19)+1;  // denominators cannot be 0
         f[j] = new Fraction (n,d);
      }
      
      System.out.println("Not Sorted: " + Arrays.toString(f));
      Arrays.sort(f);
      System.out.println(" Sorted: " + Arrays.toString(f));
      
      
      System.out.println(f[5].compareTo(f[9]));
      System.out.println(f[12].compareTo(f[2]));
      
      Fraction f5 = new Fraction(3, 4);
      Fraction f6 = new Fraction(6, 8);   
      System.out.println(f5.compareTo(f6));   


   }




}