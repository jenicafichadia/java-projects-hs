// Jenica Fichadia and Jennifer Lam pd 2

public class Name {
   private String fName;
   private String mName;
   private String lName;
   
   public Name(){
      this.fName = "";
      this.mName = "";
      this.lName = "";
   }
   
   public Name (String first, String middle, String last){
      this.fName = first;
      this.mName = middle;
      this.lName = last;
   }
   
   public String getFirst() {
      return fName;
   }
   public String getMiddle() {
      return mName;
   }
   public String getLast() {
      return lName;
   }
   public String firstMiddleLast() {
      return fName + " " + mName + " " + lName;
   }
   
   public String lastFirstMiddle() {
      return lName + ", " + fName + " " + mName;
   }
   
   public boolean Equals (Name otherName){
      boolean f = fName.equalsIgnoreCase(otherName.fName);
      boolean m = mName.equalsIgnoreCase(otherName.getMiddle());
      boolean l = lName.equalsIgnoreCase(otherName.getLast());
      return f && m && l;
   }
   
   public String initials() {
      String f = fName.substring(0,1) + mName.substring(0,1) + lName.substring(0,1);
      return f.toUpperCase();
   }
   
   public int Length(){
      return fName.length() + mName.length() + lName.length();
   }
   
}