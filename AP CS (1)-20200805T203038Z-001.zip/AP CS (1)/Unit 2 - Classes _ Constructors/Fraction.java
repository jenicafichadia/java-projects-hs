// Jenica Fichadia and Jennifer Lam pd 2

public class Fraction implements Comparable <Fraction> {
   private int n;
   private int d;
   
   public Fraction (){
      n = 0;
      d = 1;
   }
   
   public int compareTo (Fraction other) {
      if(this.decimalValue()<other.decimalValue()){
         return -1;
      }
      else if(this.decimalValue()>other.decimalValue()){
         return 1;
      }
      else {
         return 0;
      }
   }
   
   public Fraction (int n, int d){
      this.n = n;
      this.d = d;
      if(d==0){
         System.out.println("Denominator is zero");
      }
   }
   
   public int getN (){
      return n;
   }
   
   public int getD (){
      return d;
   }
   
   public void setN (int n){
      this.n = n;
   }
   public void setD (int d){
      this.d = d;
   }
   
   public Fraction add (Fraction aFraction){
      if (d == aFraction.getD()){
         n+=aFraction.getN();
         return this;
      }
      else{
         int f = d* aFraction.getN();
         d*= aFraction.getD();
         n*= aFraction.getD();
         
         n=n+f;
         this.reduce();
         return this;
      }
   }
   
   public Fraction minus (Fraction aFraction){
      if (d == aFraction.getD()){
         n -= aFraction.getN();
         return this;
      }
      else{
         int f = aFraction.getN() * d;
         d *= aFraction.getD();
         n *= aFraction.getD();
         
         n-=f;
         return this;
      }
   }
   
   public Fraction multiply (Fraction aFraction){
         n *= aFraction.getN();
         d *= aFraction.getD();
      
         return this;
   }
   public Fraction divide (Fraction aFraction){
      if(aFraction.getN()==0)
         System.out.println("Invalid");
      
      else{
         n *= aFraction.getD();
         d *= aFraction.getN();
      }
      return this;
   }
   
   public Fraction reduce() {
      int max = Math.max(n,d);
      
      for (int i=1; i<=max; i++){
         if (n%i==0 && d%i==0){
            n = n/i;
            d = d/i;
         }
      }
      return this;
   }
   
   public String toString() {
      this.reduce();
      if(d == 1){
         return n+"";
      }
      else if (n==0){
         return "0";
      }
      else{
       this.reduce();
       return n + "/" + d;
      }
      
   }
   
   public double decimalValue(){
      return (n*1.0)/d;
   }
   
   public boolean equals (Fraction aFraction){      
      if(aFraction.decimalValue()==this.decimalValue()){
         return true;
      }
      else{
         return false;
      }      
   }
   
   
   
   
   
   
   

}