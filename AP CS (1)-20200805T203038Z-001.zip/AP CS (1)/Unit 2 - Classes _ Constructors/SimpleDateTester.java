// Jenica Fichadia and Jennifer Lam pd2

public class SimpleDateTester {
   public static void main (String[] args){
      SimpleDate d1 = new SimpleDate(2002);
      SimpleDate d2 = new SimpleDate(8, 2001);
      SimpleDate d3 = new SimpleDate(13,2001);
      SimpleDate d4 = new SimpleDate(0, 2001);
      SimpleDate d5 = new SimpleDate(30,3, 1988);
      SimpleDate d6 = new SimpleDate(-9,6, 2006);
      SimpleDate d7 = new SimpleDate(31,6, 2011);
      SimpleDate d8 = new SimpleDate(29,2, 2011);
      SimpleDate d9 = new SimpleDate(29,2, 2012);
      SimpleDate d10 = new SimpleDate(30, 4, 2015);
      SimpleDate d11 = new SimpleDate(31, 5, 2015);
      SimpleDate d12 = new SimpleDate(4, 7, 1776);
      SimpleDate d13 = new SimpleDate(3, 9, 1999);
      SimpleDate d14 = new SimpleDate(31, 10, 2000);
      SimpleDate d15 = new SimpleDate(25, 11, 1999);
      SimpleDate d16 = new SimpleDate(25, 12, 2016);
      
      
      
      // Test the one argument constructor.
	// Expected output: date1 Year: 2002
	//                  date1 Month: 1
     SimpleDate date1 = new SimpleDate(31,1, 2002);
	System.out.println("date1 Year: " + date1.getYear());
	System.out.println("date1 Month: " + date1.getMonth());
   System.out.println("date1 long date: " + date1.getLongDate());
   System.out.println("date1 short date: " + date1.getShortDate());
   System.out.println("date1 is leap year: " + date1.isLeapYear());
   System.out.println("date1 days in a month: " + date1.daysInMonth());
   date1.advanceMonth();
   System.out.println("date1 long date: " + date1.getLongDate());
   System.out.println("date1 advanced Month: " + date1.getMonth());
   System.out.println();
   
   SimpleDate date16 = new SimpleDate(31,1, 2004);
   date16.advanceMonth();
   System.out.println("date16 long date: " + date16.getLongDate());

	// Test the two argument constructor.
	// Expected output: date2 Year: 2001
	//                  date2 Month: 8
	SimpleDate date2 = new SimpleDate(31,8, 2001);
	System.out.println("date2 Year: " + date2.getYear());
	System.out.println("date2 Month: " + date2.getMonth());
   date2.advanceMonth();
   System.out.println("date2 long date: " + date2.getLongDate());
   System.out.println("date2 advanced Day: " + date2.getDay());
   date2.advanceYear();
   System.out.println("date2 advanced Year: " + date2.getYear());
   System.out.println();

	// Test the two argument constructor with invalid months.
	// Expected output: date3 Month: 1
	//                  date4 Month: 1
	SimpleDate date3 = new SimpleDate(13,2001);
	SimpleDate date4 = new SimpleDate(0,2001);
	System.out.println("date3 Month: " + date3.getMonth());
	System.out.println("date4 Month: " + date4.getMonth());
   System.out.println("date3 long date: " + date3.getLongDate());
   System.out.println("date4 long date: " + date4.getLongDate());
   System.out.println("date3 short date: " + date3.getShortDate());
   System.out.println("date4 short date: " + date4.getShortDate());   
   System.out.println("date3 is leap year: " + date3.isLeapYear());
   System.out.println("date4 is leap year: " + date4.isLeapYear());
   System.out.println("date3 days in a month: " + date3.daysInMonth());
   System.out.println("date4 days in a month: " + date4.daysInMonth());
   date3.advanceMonth();
   System.out.println("date3 advanced Month: " + date3.getMonth());
   date4.advanceMonth();
   System.out.println("date4 advanced Month: " + date4.getMonth());
   System.out.println("date3 long date: " + date3.getLongDate());
   System.out.println("date4 long date: " + date4.getLongDate());
   System.out.println();
   
   // Test three argument constructor
   SimpleDate date6 = new SimpleDate(-9,6, 2006);
   System.out.println("date6 Year: " + date6.getYear());
	System.out.println("date6 Month: " + date6.getMonth());
   System.out.println("date6 Day: " + date6.getDay());
   System.out.println("date6 long date: " + date6.getLongDate());
   System.out.println("date6 short date: " + date6.getShortDate());
   System.out.println("date6 is leap year: " + date6.isLeapYear());
   System.out.println("date6 days in a month: " + date6.daysInMonth());
   date6.advanceMonth();
   System.out.println("date6 advanced Month: " + date6.getMonth());
   System.out.println();
   
   // Test last day of the month
   SimpleDate date11 = new SimpleDate(31, 5, 2015);
   date11.advanceMonth();
   System.out.println("date11 Day: " + date11.getDay());
   System.out.println("date11 Month: " + date11.getMonth());
   date11.advanceYear();
   System.out.println("date11 advanced Year: " + date11.getYear());
   System.out.println();

   SimpleDate date12 = new SimpleDate(31, 12, 2015);
   date12.advanceDay();
   System.out.println("date12 advanced Day: " + date12.getDay());
   System.out.println("date12 Month: " + date12.getMonth());
   System.out.println("date12 Year: " + date12.getYear());
   System.out.println();
   
   // test february on leap year
   SimpleDate date13 = new SimpleDate(28, 2, 2012);
   // leap year, go to 29
   System.out.println("date13 is leap year: " + date13.isLeapYear());
   date13.advanceDay();
   System.out.println("date13 advanced Day: " + date13.getDay());
   System.out.println("date13 Month: " + date13.getMonth());
   
   System.out.println("date13 Year: " + date13.getYear());
   System.out.println();
   
   // test february not leap year
   SimpleDate date14 = new SimpleDate(28, 2, 2011);
   System.out.println("date14 is leap year: " + date14.isLeapYear());
   date14.advanceDay();
   System.out.println("date14 advanced Day: " + date14.getDay());
   System.out.println("date14 Month: " + date14.getMonth());
   System.out.println("date14 Year: " + date14.getYear());
   System.out.println();

   //test last month
   SimpleDate date5 = new SimpleDate(12, 2001);
   date5.advanceMonth();
   System.out.println("date5 advanced Month: " + date5.getMonth());
   System.out.println("date5 Year: " + date5.getYear());
   System.out.println();

   
   
   
   
   
   }





}