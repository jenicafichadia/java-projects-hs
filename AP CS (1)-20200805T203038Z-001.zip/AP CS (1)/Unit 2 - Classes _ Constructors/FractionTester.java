// Jenica Fichadia and Jennifer Lam pd 2

public class FractionTester{
   public static void main(String[] args){
     Fraction f1 = new Fraction(1, 2);
     Fraction f2 = new Fraction(3, 6);
     Fraction f3 = new Fraction(3, 7);
     Fraction f4 = new Fraction(1, 5);
     Fraction f5 = new Fraction(1, 6);
     Fraction f6 = new Fraction(0, 7);
     Fraction f7 = new Fraction(10, 5);
     Fraction f8 = new Fraction(0, 8);
     Fraction f9 = new Fraction(2, 5);
     System.out.println(f1+ " = " + f2 + " : " +f1.equals(f2)); // true 
     System.out.println("3/6 reduces to " + f2.reduce()); // 1/2
 
     System.out.println(f8+ " = " + f5 + " : " +f8.equals(f5)); // false

     System.out.println(f4 + " / " + f5 + " = " + f4.divide(f5)); // 6/5
     System.out.println(f5 + " / " + f6 + " = " + f5.divide(f6));
     
     
     
     System.out.println(f7.toString()); // 2/1
     System.out.println(f6.toString()); // 0
     
     System.out.println(f2 + " + " + f9 + " = " + f2.add(f9)); // 9/10
     System.out.println(f1 + " + " + f5 + " = " + f1.add(f5)); // 2/3
     
     System.out.println(f9 + " - " + f5 + " = " + f9.minus(f5)); // 7/30
     
     System.out.println(f7 + " x " + f3 + " = " + f7.multiply(f3)); // 6/7
     
     System.out.println("The decimal value of " + f3 + " is "+ f3.decimalValue()); // 0.42857142857142855


   }
}