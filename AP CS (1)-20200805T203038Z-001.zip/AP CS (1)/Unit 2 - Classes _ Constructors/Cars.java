// Jenica Fichadia and Jennifer Lam pd 2

public class Cars{
   private String color;
   private double speed;
   
   public Cars (){
      this.color = "black";
      this.speed = 0.0;
   }
   
   public Cars (String inColor, double inSpeed){
      this.color = inColor;
      this.speed = inSpeed;
   }
   
   public double getSpeed () {
      return speed;
   }
   
   public String getColor(){
      return color;
   }
   
   public void setSpeed (double inSpeed) {
      this.speed = inSpeed;
   }
   
   public void setColor (String inColor) {
      this.color = inColor;
   }
   
   public void go () {
      speed = 60;
      System.out.println("The car is moving with the speed of " + speed);
   }
   
   public void go (double inSpeed) {
      speed = inSpeed;
      System.out.println("The car is moving with the speed of " + inSpeed);
   }
   
   public void stop (){
      speed = 0;
      System.out.println("The car is not moving. The speed is " + speed);
   }
   
   public String toString() {
      return "I am a car with speed " + speed + " and color " + color;
   }
   
   
}