// Jenica Fichadia and Jennifer Lam pd2

public class SimpleDate {
   private int day;
   private int month;
   private int year;
   
   public SimpleDate(int initYear){
      day = 1;
      month = 1;
      year = initYear;
   }
   public SimpleDate(int initMonth, int initYear){
      day = 1;
      month = initMonth;
      year = initYear;
   }
   public SimpleDate(int initDay, int initMonth, int initYear){
      day = initDay;
      month = initMonth;
      year = initYear;
   }
   
   public void advanceDay(){
      if ((month==1||month==3||month==5||month==7||month==8||month==10||month==12)&&day==31){
         if(month==12)
         {
            year++;
            month++;
            day=1;
            
         }
         month++;
         day = 1;
      }
      else if ((month==4||month==6||month==9||month==11)&&day==30){
         month++;
         day = 1;
      }
      else if(month==2){
         if (isLeapYear()==true&&day==29){
            month++;
            day = 1;
         }
         else if (isLeapYear()==false&&day == 28){
            month++;
            day = 1;
         }
         else if (isLeapYear()==true&&day == 28)
            day++;
      }
      else{
         day++;
      }
   }
   public void advanceMonth(){
      if ((month==3||month==5||month==8||month==10) && day==31){
         month ++;
         day = 30;
      }
      else if(month==7 && day==31)
         month++;
      else if(month==1 && day==31){
         if (isLeapYear()==false){
            month++;
            day=28;
         }
         else if(isLeapYear()==true){
            day=29;
            month++;
         }
      }
      else if (month==12){
         month=1;
         year++;
      }
      else{
         month++;
      }
   }
   
   public void advanceYear(){
      year++;
   }
   public int daysInMonth(){
      if (month==1||month==3||month==5||month==7||month==8||month==10||month==12){
         return 31;
      }
      else if (month==4||month==6||month==9||month==11){
         return 30;
      }
      else{//month==2
         if (isLeapYear()==true){
            return 29;
         }
         else{
            return 28;
         }
      }
   }
   public int getDay(){
      if(day>0 && day<=31)
         return day;
      else{
         day = 1;
         return day;
      }
   }
   public boolean isLeapYear(){
      if (year<1582){
         return false;
      }
      else{
         if(year%4 == 0){ // divisible by 4, true
             if(year%100==0){// divisible 4 and 100
                if(year%400==0){// divisible by 400, true
                   return true;
                }
                else{// divisible 4 and 100, false
                   return false;
                }
             }
             else{// divisible by 4, true
                return true;
             }
         }
         else{// not divisble by 4, false
            return false;
         }
                 
      }

   }
   
   public int getMonth(){
      if(month>=1 && month<=12)
         return month;
      else {
         month = 1;
         return month;
      }
   }
   
   public int getYear(){
      if(year>0)
         return year;
      else{
         year = 1;
         return year;  
      }          
   }
   
   public String getShortDate(){
      return month+"/"+day+"/"+year;
   }
   
   public String getLongDate(){
      String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
      return months[month-1] + " " + day + ", " + year;
   }
   
   
   
   
   
   
   
}