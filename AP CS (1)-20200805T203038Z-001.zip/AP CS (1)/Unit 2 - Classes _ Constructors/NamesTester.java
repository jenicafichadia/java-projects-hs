// Jenica Fichadia and Jennifer Lam pd 2
import java.util.Scanner;
public class NamesTester{
   public static void main(String[] args){
      Scanner input = new Scanner(System.in);
      System.out.print("Input first, middle and last name: ");
      String b = input.nextLine();
      System.out.print("Input first, middle and last name: ");
      String c = input.nextLine();
      System.out.print("Input first, middle and last name: ");
      String d = input.nextLine();
      
      String[] bA = b.split(" ");
      String[] cA = c.split(" ");
      String[] dA = d.split(" ");
      
      Name n1 = new Name (bA[0], bA[1], bA[2]);
      Name n2 = new Name (cA[0], cA[1], cA[2]);
      Name n3 = new Name (dA[0], dA[1], dA[2]);
      
      System.out.println(n1.firstMiddleLast());
      System.out.println(n1.lastFirstMiddle());
      System.out.println(n1.initials()); 
      System.out.println(n1.Length());
      System.out.println();
      
      System.out.println(n2.firstMiddleLast());
      System.out.println(n2.lastFirstMiddle());
      System.out.println(n2.initials());
      System.out.println(n2.Length());
      System.out.println();
      
      System.out.println(n3.firstMiddleLast());
      System.out.println(n3.lastFirstMiddle());
      System.out.println(n3.initials());
      System.out.println(n3.Length());
      System.out.println();
      
      System.out.println(n1.Equals(n2));
      System.out.println(n3.Equals(n2));
      System.out.println(n3.Equals(n1));
   }
}