// Jenica Fichadia and Jennifer Lam pd 2

public class TestVehicles{
   public static void main(String[] args){
      Cars slowCar = new Cars();
      Cars fastCar = new Cars("red", 100);
      //slow car
      System.out.println(slowCar.getSpeed());
      System.out.println(slowCar.getColor());
      slowCar.setSpeed(45);
      slowCar.setColor("green");
      System.out.println(slowCar.getSpeed());
      System.out.println(slowCar.getColor());
      System.out.println(slowCar);
      slowCar.go();
      slowCar.go(50);
      slowCar.stop();
      System.out.println();
      //fast car
      System.out.println(fastCar.getSpeed());
      System.out.println(fastCar.getColor());
      fastCar.setSpeed(0);
      fastCar.setColor("yellow");
      System.out.println(fastCar.getSpeed());
      System.out.println(fastCar.getColor());
      System.out.println(fastCar);
      fastCar.go();
      fastCar.go(120);
      fastCar.stop();
      
   }
}