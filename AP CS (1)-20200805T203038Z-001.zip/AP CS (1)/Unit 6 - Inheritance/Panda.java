// Jenica Fichadia and Jennifer Lam pd2

public class Panda extends Animal {
   private double kBamEat;
   private String origin;
   
   public Panda (String name, String sound, double k, String o){
      super(name, sound);
      kBamEat = k;
      origin = o;
   }
   
   public boolean isItStarving(){
      if(kBamEat<10) return true;
      
      return false;
   }
   
   public boolean isItFlabby(){
      if(kBamEat>20) return true;
      
      return false;
   }
   
   public String feedPanda(double k){
      kBamEat+=k;
      return "Panda is happy!";
   }
   
   public String getOrigin(){
      return origin;
   }
   
   public String toString(){
      return "The panda from " + origin + " " + super.toString() + ". It eats " + kBamEat + " kilos of bamboo.";
   }
}