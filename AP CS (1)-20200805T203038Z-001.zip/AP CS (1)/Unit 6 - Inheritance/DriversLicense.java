// Jenica Fichadia pd 2

public class DriversLicense extends Card{
   private int licenseNum;
   private int expDate;
   
   public DriversLicense(String name, int ln, int eD){
      super(name);
      licenseNum = ln;
      expDate = eD;
   }
   
   public void printCard(){
      super.print();
      System.out.println("License Number: " + licenseNum);
      System.out.println("Expiration Date: " + expDate);

   }
   public boolean isExpired(){
      if(2018>expDate)
         return true;
      return false;
   }
   
   
 
}