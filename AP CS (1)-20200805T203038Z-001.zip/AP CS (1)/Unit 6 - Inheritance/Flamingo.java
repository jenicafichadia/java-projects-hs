// Jenica Fichadia and Jennifer Lam pd2

//gray, white (young), red, orange, pink 

public class Flamingo extends Animal{
   private String color;
   private boolean longLegs;
   
   public Flamingo(String name, String sound, String c, boolean lL){
      super(name, sound);
      color = c;
      longLegs = lL;
   }
   
   public String getColor(){
      return color;
   }
   
   public void ageUp(){
      if(color.equalsIgnoreCase("gray")) color = "white";
      else if (color.equalsIgnoreCase("white")) color = "red";
      else if (color.equalsIgnoreCase("red")) color = "orange";
      else if (color.equalsIgnoreCase("orange")) color = "pink";
      else color = "black; it's dead";
   }
   
   public boolean getLongLegs(){
      return longLegs;
   }
   
   public String toString(){
      return "The flamingo " + super.toString() + ". it's color is " + color + " and it has long legs? " + longLegs;
   }
   
   

}