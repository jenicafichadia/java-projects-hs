 // Jenica Fichadia and Jennifer Lam pd 2
 
public class Animal { 
   private String myName; 
   private String mySound; 
    
   public Animal()  
   { 
      myName = ""; 
      mySound = ""; 
   } 
   public Animal(String newName, String newSound){ 
      myName = newName; 
      mySound = newSound; 
   } 

   public String getName(){ 
      return myName; 
   } 
   
   public String getSound(){ 
      return mySound; 
   } 
  
   public String toString() { 
      return myName + " says " + mySound; // send name, 
      // sound to the caller 
   }  
   
   
   
   
   
} 