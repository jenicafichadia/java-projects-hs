// Jenica Fichadia and Jennifer Lam pd2

public class Cow extends Animal {
   // no instance variables; all are inherited from Animal 

   public Cow(String newName, String newSound){ 
      super(newName, newSound); 
   }
   
   public String toString(){
      return "The cow " + getName() + " says " + this.getSound() + ".";
   }
// no methods needed; all are inherited from Animal 
} 
