// Jenica Fichadia 

public class IDCard extends Card{
   private int idnum;
   
   public IDCard(String name, int id) {
      super(name);
      idnum = id;
   }
   
   public void printCard(){
      super.print();
      System.out.println("ID Number: " + idnum);
   }


}