// Jenica Fichadia and Jennifer Lam pd 2

public class SciFi extends Movie {
   private double complex;
   
   public SciFi (int s, String t, double c){
      super(s, t);
      if(c<4.0)
         c = 4.0;
      else if(c>10.0)
         c = 10.0;
      else{}
      complex = c;
   }
   
   public double getComplex(){
      return complex;
   }
   
   public int compareTo (Movie that){
      if(this.getGenre().equals("SciFi") && that.getGenre().equals("SciFi")){
         if(((SciFi)this).getComplex() > ((SciFi)that).getComplex()) return 1;
         else if (((SciFi)this).getComplex() == ((SciFi)that).getComplex()) return 0;
         else return -1;
      }
      else{
         return super.compareTo(that);
      }
   }
   
   public String toString(){
      return super.toString() + " Complexity: " + complex;
   }
   
   public String getGenre(){
      return "SciFi";
   }
   

}