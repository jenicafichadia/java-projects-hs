// Jenica Fichadia and Jennifer Lam pd2

public class MovieTrilogy extends Movie{
   private Movie m1;
   private Movie m2;
   private Movie m3;
   
   public MovieTrilogy(Movie a, Movie b, Movie c){
      super(((a.getScore()+b.getScore()+c.getScore())/3), (a.getTitle() + "/" + b.getTitle() + "/" + c.getTitle()));
      m1 = a;
      m2 = b;
      m3 = c;
   }
   
   public String getGenre(){
      if (m1.getGenre().equals(m2.getGenre()) && (m2.getGenre().equals(m3.getGenre())))
         return m1.getGenre();
  
      else
         return "Trilogy";
   }

}