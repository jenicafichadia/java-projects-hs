// Jenica Fichadia and Jennifer Lam pd2

public class Penguin extends Animal{
   private int speed;
   private boolean superWaddle;
   
   public Penguin(String name, String sound, int s, boolean sW){
      super(name, sound);
      if(s>25) s= 25;
      speed = s;
      superWaddle = sW;
   }
   
   public boolean isInWater(){
      if(speed>5) return true;
      
      return false;
   }
   
   public int getSpeed(){
      return speed;
   }
   
   public void setSpeed(int s) {
      speed = s;
   }
   
   public boolean getSuperWaddle(){
      return superWaddle;
   }
   
   public String toString(){
      return "The penguin " + super.toString() + ". It goes " + speed + " mph and it superwaddles? " + superWaddle;
   }

}