// Jenica Fichadia and Jennifer Lam pd2

public class ZooTester{
   public static void main(String[] args){
      Zoo exhibit = new Zoo();
      Camel a = new Camel("Cissy", "grunt", 5);
      Cow b = new Cow("Bessy", "MOOOO");
      exhibit.addResident(a);
      exhibit.addResident(b);
      Animal flam = new Flamingo("Fannie", "screak", "gray", true);
      Panda pan = new Panda("Peter", "munch", 6, "Canada");
      Penguin peng = new Penguin("Penny", "quack", 23, true);
      exhibit.addResident(flam);
      exhibit.addResident(pan);
      exhibit.addResident(peng);
      
      System.out.println(a);
      System.out.println();
      System.out.println(b); 
      System.out.println();     
      
      System.out.println(flam);
      ((Flamingo)flam).ageUp();
      System.out.println("Color: " + ((Flamingo)flam).getColor());
      if (((Flamingo)flam).getLongLegs()==true)  System.out.println("It's got supa long legs.");
      else  System.out.println("It's just a normal flamingo.");
      System.out.println(flam);
      System.out.println();
      
      System.out.println(pan);
      if (pan.isItStarving()==true)  System.out.println("Feeding 25 kilos: " + pan.feedPanda(25));
      if(pan.isItFlabby()==true)  System.out.println("IT'S FLABBY.");
      else  System.out.println("Poor baby...");
      System.out.println(pan);
      System.out.println();
      
      System.out.println(peng);
      System.out.println("Are you looking for food? " + peng.isInWater());
      peng.setSpeed(3);
      if(peng.getSpeed()<5)  System.out.println("I have eaten");
      if(peng.getSuperWaddle()==true)  System.out.println("Flap flap.");
      else  System.out.println("Penguin crossing.");
      System.out.println(peng);
      System.out.println();
      
      System.out.println("Zoo residents: ");
      exhibit.getResidents();

      
   }
   
   
}