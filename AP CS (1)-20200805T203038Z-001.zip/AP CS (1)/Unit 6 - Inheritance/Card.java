// Jenica Fichadia and Jennifer Lam pd 2

public class Card implements Comparable<Object>{  
   public Card(){
     name = "";
   }
   public Card(String n) {
    name = n;
   }
   public String getName(){
      return name;
   }
   public boolean isExpired(){
      return false;
   }
   public void print(){
      System.out.println("Card holder: " + name);
   }
   public int compareTo(Object other){
      return ((Card)other).getName().compareTo(this.getName());
      /*int a = (int)(this.getName().charAt(0));
      int b = (int)(c.getName().charAt(0));
      if(a>b) return 1;  
      else if(a<b) return -1;
      else return 0;*/
   }
   public boolean equals(Object other){
      return (this.getName()).equals(((Card)other).getName());
      /*if(this.getName().equals(((Card)other).getName())) return true;
      return false;*/
   }
   public String toString(){
      return "Card [name= " + name + "]";
   }
   public Object clone(){
      Object a = new Card(this.getName());
      return a;
   }
   private String name;
}
