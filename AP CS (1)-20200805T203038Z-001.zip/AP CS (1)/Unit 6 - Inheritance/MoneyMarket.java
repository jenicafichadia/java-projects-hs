// Jenica Fichadia and Jennifer Lam pd2 

public class MoneyMarket extends Savings{
   private int numWithdrawals;
   
   public MoneyMarket(int acctNum, String name, double bal, double rate){
      super(acctNum, name, bal, rate);
   }
   
   public void withdraw(double amt){
      super.withdraw(amt);
      numWithdrawals++;
   }
      
   public void deductPenalty(){
      if(numWithdrawals>3)
         changeBalance(-1*(getBalance()*0.1));
   
   }
   
   public int getNumWithdrawals (){
      return numWithdrawals;   
   }
   





}