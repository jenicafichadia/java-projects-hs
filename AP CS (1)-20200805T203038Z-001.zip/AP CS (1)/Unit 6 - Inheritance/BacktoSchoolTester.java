// Jenica Fichadia and Jennifer Lam pd2

public class BacktoSchoolTester{

   public static void main(String[] args){
      /*Person bob = new Person("Coach Bob", 27, "M");
      System.out.println(bob);

      Student lynne = new Student("Lynne Brooke", 16, "F", "HS95129", 3.5);
      System.out.println(lynne);

      Teacher mrJava = new Teacher("Duke Java", 34, "M", "Computer Science", 50000);
      System.out.println(mrJava);

      CollegeStudent ima = new CollegeStudent("Ima Frosh", 18, "F", "UCB123",
                                         4.0, "English", 1);
      System.out.println(ima);*/
      
      Student jennifer = new Student("Jennifer Lam", 16, "F", "1452618", 4.2);
      System.out.println(jennifer);
      System.out.println("GPA: " + jennifer.getGPA());
      System.out.println("Gender: " + jennifer.getGender());
      jennifer.setAge(17);
      System.out.println("Age: " + jennifer.getAge());
      System.out.println(jennifer);
      System.out.println();
      
      
      CollegeStudent coolkid = new CollegeStudent("John Smith", 17, "F", "UDK2156", 4.46, "Rocket Science", 2);
      System.out.println(coolkid);
      coolkid.setName("Cool Kid");
      System.out.println("Name: " + coolkid.getName());
      coolkid.setMajor("Music Theory");
      System.out.println("Major: " + coolkid.getMajor());
      coolkid.setGPA(4.2);
      coolkid.setIdNum("SDF56423");
      System.out.println("ID: " + coolkid.getIdNum());
      System.out.println(coolkid);
      System.out.println();
      
      Person mP = new Person("Mr. PotatoHead", 12, "M");
      System.out.println(mP);
      mP.setGender("F");
      System.out.println("Gender: " + mP.getGender());
      mP.setName("Mrs. PotatoHead");
      System.out.println("Name: " + mP.getName());
      System.out.println(mP);
      System.out.println();
      
      Teacher mean = new Teacher ("Mrs. Grave", 63, "F", "Gym", 20000.0);
      System.out.println(mean);
      mean.setAge(70);
      mean.setSubject("English");
      mean.setSalary(30000.0);
      System.out.println("Age: " + mean.getAge());
      System.out.println("Subject: " + mean.getSubject());
      System.out.println("Salary: " + mean.getSalary());
      System.out.println(mean);
      

   }
}