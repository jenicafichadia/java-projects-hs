// Jenica Fichadia and Jennifer Lam pd 2

public class CollegeStudent extends Student{
   private String major;
   private int year;
   
   public CollegeStudent(String name, int age, String gender,String idNum, double gpa, String m, int y){
      super(name, age, gender, idNum, gpa);
      major = m;
      year = y;
   }
   
   public void setMajor (String m){
      major = m;
   }
   
   public void setYear (int y){
      year = y;
   }
   
   public String getMajor(){
      return major;
   }
   
   public int getYear(){
      return year;
   }
   
   public String toString(){
      return super.toString() + ", Major: " + major + ", Year: " + year;
   }
}