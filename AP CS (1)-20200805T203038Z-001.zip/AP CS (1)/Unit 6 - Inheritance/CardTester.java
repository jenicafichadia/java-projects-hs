// Jenica Fichadia pd 2

public class CardTester{
   public static void main (String[] args){
      Card c1 = new IDCard("Isabella", 5685);
      Card c2 = new PhoneCard("Jenica", 56545);
      Card c3 = new DriversLicense("Jessica", 41353, 2016);
      Card c4 = (Card)(c2.clone());
      BillFold b = new BillFold(); 
      
      ((IDCard)c1).printCard();
      System.out.println();
      System.out.println("Is " + c1.getName() + "'s card expired? " + ((IDCard)c1).isExpired());
      System.out.println();
      
      ((PhoneCard)c2).printCard();
      System.out.println();
      System.out.println("Is " + c2.getName() + "'s card expired? " + ((PhoneCard)c2).isExpired());
      System.out.println();
      
      ((DriversLicense)c3).printCard(); 
      System.out.println();
      System.out.println("Is " + c3.getName() + "'s card expired? " + ((DriversLicense)c3).isExpired());
      System.out.println();
      
      b.addCard(c1);
      b.addCard(c3);
      System.out.println("The following cards are in the billfold: ");
      b.printCards(); 
      System.out.println();
      System.out.println("The following cards are expired: ");
      b.printExpiredCards();
      System.out.println();
      
      if((c1.compareTo(c3)!=0))  System.out.println("The first and third card are not from the same person.");
      else  System.out.println("The first and third card are from the same person.");
      if (c2.equals(c4))  System.out.println("The second and fourth card are from the same person.");
      else  System.out.println("The second and fourth card are not from the same person.");
   }

}