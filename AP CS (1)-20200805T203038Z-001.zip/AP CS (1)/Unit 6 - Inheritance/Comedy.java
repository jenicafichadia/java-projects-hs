// Jenica Fichadia and Jennifer Lam pd 2

public class Comedy extends Movie{
   private int laugh;
   
   public Comedy(int s, String t, int l){
      super(s, t);
      laugh = l;
   }
   
   public int getLaughs(){
      return laugh;
   }
   
   public int compareTo (Movie that){
      if(this.getGenre().equals("Comedy") && that.getGenre().equals("Comedy")){
         if(((Comedy)this).getLaughs() > ((Comedy)that).getLaughs()) return 1;
         else if (((Comedy)this).getLaughs() == ((Comedy)that).getLaughs()) return 0;
         else return -1;
      }
      else{
         return super.compareTo(that);
      }
   }
   
   public String toString(){
      return super.toString() + " Average Laughs: " + laugh;
   }
   
   public String getGenre(){
      return "Comedy";
   }
   
}
