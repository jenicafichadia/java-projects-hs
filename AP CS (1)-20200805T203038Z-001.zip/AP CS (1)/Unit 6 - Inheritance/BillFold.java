// Jenica Fichadia pd 2

public class BillFold {
   private Card card1;
   private Card card2;
   
   public BillFold(){
      card1 = null;
      card2 = null;
   }
   
   public void addCard (Card c){
      if(card1==null)
         card1 = c;
      else if(card2==null)
         card2 = c;
         
   }
   
   public void printCards(){
      if(card1 != null)
         card1.print();
      if(card2 != null)
         card2.print();
   }
   
   public void printExpiredCards(){
      if( card1 != null && card1.isExpired()==true)
         ((DriversLicense)card1).printCard();
      else if ( card2 != null && card2.isExpired()==true)
         ((DriversLicense)card2).printCard();

   }
   
   
}