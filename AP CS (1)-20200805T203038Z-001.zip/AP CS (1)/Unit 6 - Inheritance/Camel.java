// Jenica Fichadia and Jennifer Lam pd2

public class Camel extends Animal { 

   private int myHumps; 

   public Camel(String newName, String newSound, int newHumps) { 
      super (newName, newSound);  
      myHumps = newHumps;  
   } 
 
   public String toString() { 
      String message = "The camel " + getName() + " says "; 
      message += getSound() + " and has " + myHumps + " humps."; 
      return message; 
   } 

}  
