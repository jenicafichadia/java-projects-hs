// Jenica Fichadia and Jennifer Lam pd 2

public abstract class Movie {
   private int score;
   private String title;
   
   public Movie(int s, String t){
      score = s;
      title = t;
   }
   
   public String getTitle(){
      return title;
   }
   
   public int getScore(){
      return score;
   }
   
   public int compareTo (Movie that){
      if(this.getScore() > that.getScore()) return 1;
      else if (this.getScore() == that.getScore()) return 0;
      else return -1;
   }
   
   public String toString(){
      return "Title: " + title + " Score: " + score;
   }
   
   public abstract String getGenre();

}