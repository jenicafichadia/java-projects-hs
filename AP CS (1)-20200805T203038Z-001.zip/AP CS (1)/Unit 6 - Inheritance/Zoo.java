// Jenica Fichadia and Jennifer Lam pd2

import java.util.ArrayList;

public class Zoo { 
  // instance variables 
   private ArrayList<Animal> residents;
 
   public Zoo() { 
      residents = new ArrayList<Animal>();      
   } 
/** 
*getResidents()displays the info of each animal instance 
*/ 
   public void getResidents() { 
      for(int i=0; i<residents.size(); i++){
         System.out.println(residents.get(i));
      } 
   }
   
   public void addResident(Animal o){
      residents.add(o);
   } 
   
   
}
