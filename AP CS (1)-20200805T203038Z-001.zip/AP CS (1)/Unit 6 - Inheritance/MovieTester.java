//Jenica Fichadia and Jennifer Lam pd 2

public class MovieTester{
   public static void main(String[] args) {
      Comedy c = new Comedy(5, "BigFoot Parotty", 42);
      Movie m = new Comedy(1, "Return of Mr PotatoHead", 8747);
      Comedy p = new Comedy(8, "I ate a potato.", 284);
      SciFi s = new SciFi(9, "Back to the Future", 36);
      MovieTrilogy t = new MovieTrilogy(c, m, s);
      MovieTrilogy o = new MovieTrilogy(c, m, p);
      
      if (c.compareTo(m)>0) System.out.println(c.getTitle() + " is better than " + m.getTitle());
      else if (c.compareTo(m)<0) System.out.println(m.getTitle() + " is better than " + c.getTitle());
      else System.out.println(m.getTitle() + " is the same as " + c.getTitle());
      
      System.out.println(c.getTitle() + " avg num of laughs: " + c.getLaughs());
      System.out.println(m.getTitle() + " avg num of laughs: " + ((Comedy)m).getLaughs());
      System.out.println(s.getTitle() + " complexity lvl: " + s.getComplex());
      System.out.println();
      
      System.out.println(c.getTitle() + " score: " + c.getScore());
      System.out.println(m.getTitle() + " score: " + m.getScore());
      System.out.println(s.getTitle() + " score: " + s.getScore());
      System.out.println(p.getTitle() + " score: " + p.getScore());
      System.out.println(t.getTitle() + " score: " + t.getScore());
      System.out.println(o.getTitle() + " score: " + o.getScore());
      System.out.println();
      
      System.out.println(c.getTitle() + " genre: " + c.getGenre());
      System.out.println(m.getTitle() + " genre: " + m.getGenre());
      System.out.println(s.getTitle() + " genre: " + s.getGenre());
      System.out.println(p.getTitle() + " score: " + p.getGenre());
      System.out.println(t.getTitle() + " genre: " + t.getGenre());
      System.out.println(o.getTitle() + " genre: " + o.getGenre());
      System.out.println();
      
      System.out.println(m);
      System.out.println(c);
      System.out.println(s);
      System.out.println(t);
      System.out.println(p);
      
         
      
   }
}