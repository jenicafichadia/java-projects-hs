// Jenica Fichadia pd 2

public class PhoneCard extends Card{
   private int phoneNum;
   
   public PhoneCard(String name, int pn){
      super(name);
      phoneNum = pn;
   } 
   
   public void printCard(){
      super.print();
      System.out.println("Phone Number: " + phoneNum);
   }
   

}