// Jenica Fichadia and Jennifer Lam pd2

public class Teacher extends Person{
   private String subject;
   private double salary;
   
   public Teacher(String myName, int myAge, String myGender, String b, double a){
      super(myName, myAge, myGender);
      subject = b;
      salary = a;
   } 
   
   public void setSubject (String s){
      subject = s;
   }
   
   public void setSalary (double s){
      salary = s;
   }
   
   public String getSubject(){
      return subject;
   }
   
   public double getSalary(){
      return salary;
   }
   
   public String toString(){
      return super.toString() + ", Subject: " + subject + ", Salary: " + salary;
   }
}