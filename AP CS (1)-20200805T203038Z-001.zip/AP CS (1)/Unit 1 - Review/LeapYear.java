// Jenica Fichadia
import java.util.Scanner;

public class LeapYear {
   public static void main (String[] args) {
        Scanner input = new Scanner(System.in);
        
        int year = -1;
        while(year!=0){
           System.out.print("Enter a year 1582 or greater(0 to quit): ");
           year = input.nextInt();
        
           if(year==0){
               System.out.println("Goodbye");
           }
           else if (year<1582){
              System.out.println("Invalid year");
           }
           else{
              if(year%4 == 0){
                  if(year%100==0){
                     if(year%400==0){
                        System.out.println(year + " is a leap year");
                     }
                     else{
                        System.out.println(year + " is not a leap year");
                     }
                  }
                  else{
                     System.out.println(year + " is a leap year");
                  }
              }
              else{
               System.out.println(year + " is not a leap year");
              }
                     
           }
        }
        
        
        
        
   }
}