// Jenica Fichadia pd 2

public class StringDr {
      public static void main (String[] args)
      {
      
      // Write this method last 
      // Directions are at the bottom of the sheet.
      
         String s1 = "McLean";
         String s2 = "abacus";
         String s3 = "abacus";
         String s4 = "calc";
         
      
         System.out.println(s1+ " is the same as "+s2 +": " + same(s1,s2));
         System.out.println(s2+ " is the same as "+s3 +": " + same(s2,s3));
         System.out.println();
         
         System.out.println("the 5th character of "+s1 +" is "+findNth(s1,5));   
         System.out.println("the 5th character of "+s4 +" is "+findNth(s4,5));  
         System.out.println();
      
         System.out.println(s2+ " starts with a vowel: "+startsWithAVowel(s2));
         System.out.println(s4+ " starts with a vowel: "+startsWithAVowel(s4));
         System.out.println();
      
         System.out.println(s1+ " starts with an uppercase letter: "+startsUpperCase(s1));
         System.out.println(s2+ " starts with an uppercase letter: "+startsUpperCase(s2));
         System.out.println();
      
         System.out.println(s1+ " has the letter: c: "+hasLetter(s1,'c'));
         System.out.println(s4+ " has the letter: e: "+hasLetter(s4,'e'));
      }
     
   /**
   * Returns true if s1 and s1 have the same characters
   * in the same order. Example:
   *   
   *   same("hi", "hi")
   *   true
   */
      public static  boolean same(String s1, String s2){
         return s1.equals(s2);  // CHANGE - how will == compare Strings
      }
   
   /**
   * Returns the nth char in str if there is one.
   * If not, the null characters '\0' is returned.
   * If n is 1, the first character is returned.
   *   
   *   findNth("yo", 5)  none, there are only 2 characters
   *   '\0'
   *   findNth("yo", 1)
   *   'y'
   
   
   */
      public static  char findNth(String str, int n){
      

      
      
         return '\0';
      }
   
   /**
   * Returns true if the word starts with a vowel, 
   * false otherwise. This method is case sensitive.
   */
      public static boolean startsWithAVowel(String word){
         
            
         return false;
      }
   
   /**
   *  Returns true if the word starts with an uppercase letter
   * (ignoring case); false otherwise.
   */
      public static  boolean startsUpperCase(String word){
     
               
      
         return false;
      }
   
   /**
   *  Returns true if str contains a letter. Check with the API to see if there is an
   * easy way to do this
   */
      public static boolean hasLetter(String str, char let){
      
      
      
         return false;
      }
   
      
   }

