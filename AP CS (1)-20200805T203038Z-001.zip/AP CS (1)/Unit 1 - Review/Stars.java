// Jenica Fichadia pd 2

public class Stars{
   public static void main (String[] args) {
      Stars s1 = new Stars();
      s1.printTriangle(6);
      System.out.println();
      s1.printTriangle(10);
      System.out.println();
      s1.printTriangle(14);
      System.out.println();
      s1.printArrow(6); 
      System.out.println(); 
      s1.printDiamond(6);
      System.out.println();
      s1.printX(6);
   }
   
      public void printTriangle (int rows) {
         for(int i=1; i<=rows; i++){
            for (int j = 1; j <= i; j++) {
               System.out.print("*");
            }
            System.out.println();
         }

      }
      
      public void printArrow (int rows){
         printTriangle(rows);
         for(int i=rows-1; i>=1; i--){
            for (int j = 1; j <= i; j++) {
               System.out.print("*");
            }
            System.out.println();
         }

      }
      public void printDiamond (int rows){
         for (int i = rows; i >= 1; i--) {
           for (int j = 1; j <= (i - 1); j++) {
              System.out.print(" ");
           }
           for (int k = 1; k <= (11 - 2 * i); k++) {
              System.out.print("*");
           }
           System.out.println();
         }

      
         for (int i = 2; i <= rows; i++) {
           for (int j = 1; j <= (i - 1); j++) {
              System.out.print(" ");
           }
           for (int k = 1; k <= (11 - 2 * i); k++) {
              System.out.print("*");
           }
           System.out.println();
         }

      }
      
      public void printX(int rows) {
         System.out.print(" ");
         for (int i=rows; i>0; i--){// top
            for(int j=1; j<=rows-i; j++) {//left side
               System.out.print("*");
            }
            System.out.print(" ");
            for (int k = 1; k <= (11 - 2 * i); k++) {
              System.out.print("*");
           }
           
        }
 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
      }
   
}