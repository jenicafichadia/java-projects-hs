// Jenica Fichadia and Jennifer Lam pd 2

public class TestStuff{
   public static void main(String[] args){
      System.out.println (fes(0));
      System.out.println();
      home(9);
      System.out.println();
      method(7);
      System.out.println();
      System.out.println(pls(4));
      System.out.println();
      what(4);
      System.out.println();
      gigi(11,2);
      System.out.println();
      System.out.println(rig(4));
      System.out.println();
      System.out.println(mm(6));
      System.out.println();
      System.out.println(admin(5));
      System.out.println();
      System.out.println(zz(0));
      System.out.println();
      elvis(11);
      System.out.println();
      System.out.println( "sal: " + sal(5));
      System.out.println();
      puff(4);
      System.out.println();
      bbc(6,2);
      System.out.println();
      weirdom(40);
      System.out.println();
      System.out.println("product: " + product(1));
      System.out.println();
      System.out.println("negative: " + negative(-3));
      System.out.println();
      System.out.println("identity: " + identity(10));
      System.out.println();
   
   }
   
   public static int fes(int n) {
      if (n>6) 
        return n-3;
      else {
        n=n*2;
        return  n+fes(n+1);
      }
   }
   
   public static void home(int n) {
      if (n<=1) 
         System.out.print(n);
      else {
         home(n/2);
         System.out.print(","+n);
      }
   }
   public static void method(int n) {
      if (n<=1) 
         System.out.print(n);
      else {
         method(n-2);
         System.out.print(","+n);
      }
   }

   public static int pls(int n) {
      if (n==0) 
         return 5;
      else if (n==1) 
         return 11;        
      else {
         return pls(n-1)+2*pls(n-2);
      }   
   }
   
   public static void what(int z) {
      if (z==0) 
         System.out.print("z");
      else {
         System.out.print("{");
         what(z-1);
         System.out.print("}");
      }
   }

   public static void gigi(int x, int y) {
      if (x/y!=0) {
         gigi(x/y, y);
      }
      System.out.print(x/y+1);
   }
   
   public static int rig(int n) {
      if (n==0) 
         return 5;
      else if (n==1) 
         return 8;
      else {
         
         return  rig(n-1)-rig(n-2);
      }
   }

   public static int mm(int n) {
      if (n<=0) 
         return 10;
      else 
         return  n+mm(n-1);
   }

   public static int admin(int n) {
      if (n<=1) 
         return n;
      else 
         return  n*admin(n-2);
   }

   public static int zz(int n) {
      if (n>10) 
         return n-2;
      else {
         n=n*3;
         return n+ zz(n+2);
      }
   }

   public static void elvis(int n) {
      if (n<=3) 
         System.out.print(n+1);
      else {
         elvis(n-3);
         System.out.print(">>"+(n-1));
      }
   }

   public static int sal(int n) {
      if (n==2) 
         return 100;
      else if (n==3) 
         return 200;
      else {
         return  (2*sal(n-1)+sal(n-2)+1);
      }
   }

   public static void puff(int n) {
      if (n==1){ 
         System.out.print("x");
      }
      else if (n%2==0)
      {
         System.out.print("{");
         puff(n-1);
         System.out.print("}");
      }
      else
      {

         System.out.print("<");
         puff(n-1);
         System.out.print(">");
      
      }
   }

   public static void bbc(int p, int q) {
      if (p/q==0) 
         System.out.println(p+q+1);
      else {
         System.out.println(p);
         bbc(p/q, q);
      }
   }

   public static void weirdom(int x){
     System.out.print(x + " ");
       if( x > 1 ){
          weirdom(x/2);
       }
  }

   public static int product(int num){
      if(num > 20){
         return -1;
      }
      else{
         return num * product(-2 * num);
      }
   }
   
   public static int negative(int num){
      if(num >= 20){
         return -5;
      }
      else{
         return negative(num + 4) + 2 * num;
      }
   }

   public static int identity(int num){
      if(num < 1){
         return 10;
      }
      else{
         return num + identity(num - 2);
      }
   }
    
    
    
    
    
}
