//Jenica Fichadia and Jennifer Lam pd 2

public class AccidentsTester{
   public static void main(String[] args){
      Accidents a = new Accidents();
      System.out.println(a.toString());
      System.out.println("Total accidents per month: " + a.totalPerMonth());
      System.out.println("Hour with most accidents: " + a.mostAccidents());
   }
}