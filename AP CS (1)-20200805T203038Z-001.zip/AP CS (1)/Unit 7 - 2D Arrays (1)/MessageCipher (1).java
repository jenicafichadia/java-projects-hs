// Jenica Fichadia and Jennifer Lam pd2
import java.util.*;

public class MessageCipher {
   private String[][] letterBlock;
   private int numRows;
   private int numCols;

   public MessageCipher (int row, int col){
      numRows=row;
      numCols=col;
      letterBlock = new String[row][col];
   }

   public void fillBlock(String str){ 
      int s = 0;
      for(int r=0; r<numRows; r++){
         for(int c=0; c<numCols; c++){
            if(s<(str.length())){
               letterBlock[r][c] = str.substring(s, s+1);
               s++;
            }
            else
               letterBlock[r][c] = "A";
         }
      }
   
   }
   
   public void printTable(){ 
      String s = "";

      for(int r=0; r<numRows; r++){
         for(int c=0; c<numCols; c++){
            s+=letterBlock[r][c] + "  ";
         }
         s+="\n"; 
      }
      System.out.println(s);
   }
   
   
   public String encryptBlock(){ 
      String s = "";
      for(int c=0; c<numCols; c++){
         for(int r=0; r<numRows; r++){   
            s+=letterBlock[r][c];
         }
      }
      return s;
   }
   
   public String encryptMessage(String message){
      int i = 0; //amount of times it has run so far
      String s = "";
      int sS = 0; //substring num
      while (i < message.length()){
         this.fillBlock(message.substring(i)); //fills in
         s+=this.encryptBlock(); //encrypts
         i+=numRows*numCols;
      }
      return s;
   }
      
}
   

   
   
   
   
         
 

