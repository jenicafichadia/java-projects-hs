//Jenica Fichadia and Jennifer Lam pd 2

public class Accidents{
   public static final int DAYS = 31;
   public static final int HOURS = 24;
   
   private int[][]accidents;
   
   public Accidents(){
      accidents = new int[DAYS][HOURS];
      for (int r = 0; r < DAYS; r++){
         for (int c = 0; c < HOURS; c++){
            accidents[r][c] = (int)(Math.random()*9);
         }
      }
   }
   
   public String toString(){
      String s = "Accidents Table\n";
      int day = 1;
      for (int r = 0; r < DAYS; r++){
         s+="Day " + day + "\t";
         day++;
         for (int c = 0; c < HOURS; c++){
            s+=accidents[r][c] + " ";
         }
         s+="\n";
      }
      return s;
   }
   
   public int totalPerMonth(){
      int total = 0;
      for (int r = 0; r < DAYS; r++){
         for (int c = 0; c < HOURS; c++){
            total+=accidents[r][c];
         }
      }
      return total;
   }
   
   public int mostAccidents(){
      int most = 0;
      int temp = 0;
      int hour = 0;
      for (int hours = 0; hours < HOURS; hours++){
         for (int day = 0; day < DAYS; day++){
            temp+=accidents[day][hours];
         }
         if (temp>most){
            hour = hours;
            most = temp;
         }
         temp=0;          
      }
      return hour;
   }
}