// Jenica Fichadia and Jennifer Lam pd2

import java.util.*;

public class MessageCipher_Tester{
   public static void main (String [] args){
      MessageCipher puzzle= new MessageCipher(2,3);
      puzzle.fillBlock("Meet at midnight");
      puzzle.printTable();
      System.out.println(puzzle.encryptMessage("Meet at midnight"));
      puzzle.fillBlock("Meet at noon");
      puzzle.printTable();
      System.out.println(puzzle.encryptBlock()); 
   }
}
