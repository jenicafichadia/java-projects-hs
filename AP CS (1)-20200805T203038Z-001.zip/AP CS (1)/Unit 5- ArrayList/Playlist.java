// Jenica Fichadia and Jennifer Lam pd 2
import java.util.*; 

public class Playlist{
  
  //Instance variable
  private ArrayList<Song> songs;  //arraylist of songs
  private String name; //Playlist name
  
  
  public Playlist(String name){ 
    songs = new ArrayList<Song>();  //initalize Arraylist to hold Song type
    this.name = name;
  }
  
  //Methods:

 //Returns the playlist name
  public String playlistName(){
   return name;   
  }

  //adds Song s to Playlist
  public boolean addSong(Song s){
    return songs.add(s); 
  }
  
  public boolean removeSong(Song s){
    boolean tf = false;
    for(int i = 0; i< songs.size(); i++){
      if((s.getSongName().compareTo(songs.get(i).getSongName())==0) && (s.getArtist().compareTo(songs.get(i).getArtist())==0) && (s.getPlayTime()==songs.get(i).getPlayTime()) && tf==false){
         tf = true;
         songs.remove(s);
      }
    }
    return tf;
  }
  
  public double playlistTime(){
     double t = 0;
     for(int i=0; i<songs.size(); i++){
        t+=songs.get(i).getPlayTime();
     }
     return t;
  }
  
  public int totalSongs(){
    return songs.size();
  }
  
  public boolean isSongInPlaylist(String name){
    boolean tf = false;
    for (Song s: songs){
      if (s.getSongName().equals(name)){
         tf = true;
      }
    }
    return tf;
  }
  
  public void songsByArtist(String name){
     for (Song s: songs){
        if (s.getArtist().equals(name)){
           System.out.println(s);
        }
     }
  }
  
  public boolean addSongsFrom(Playlist p){
     List<Song> s = p.getList();
     for (int i = 0; i < p.totalSongs(); i++){
        songs.add(s.get(i));
     }
     //Collections.sort(songs, new Song());
     for(int i=0; i<songs.size(); i++){
         for (int j=i+1; j<songs.size(); j++){
            if((songs.get(i).getSongName().compareTo(songs.get(j).getSongName())>0) && (songs.get(i).getArtist().compareTo(songs.get(j).getArtist())>0) && (songs.get(i).getPlayTime()>songs.get(j).getPlayTime())){
               Song temp = songs.get(i);
               songs.set(i, songs.get(j));
               songs.set(j, temp);
            }
         }
      }

      for(int i=1; i<songs.size(); i++){
         if((songs.get(i).getSongName().compareTo(songs.get(i-1).getSongName())>0) && (songs.get(i).getArtist().compareTo(songs.get(i-1).getArtist())>0) && (songs.get(i).getPlayTime()>songs.get(i-1).getPlayTime())){
            songs.remove(i-1);
            i--;
         }
      }
      return true;
   }
     
     
  //return list. Note return is List<Song>.
  public List<Song> getList(){
     System.out.println(this.toString());
     return songs;
  }
  
  public String toString(){
     String s = "";
     for (int i = 0; i < songs.size(); i++){
        s+=songs.get(i).toString() + " ";
     }
     return s;
  } 
  
}//end of class Playlist
