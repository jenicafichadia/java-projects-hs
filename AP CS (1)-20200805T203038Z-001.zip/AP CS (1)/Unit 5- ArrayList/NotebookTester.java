// Jenica Fichadia and Jennifer Lam pd 2

public class NotebookTester{
   public static void main(String[] args){
      Notebook n = new Notebook();
      
      n.storeNote("I am so Tired"); // stores at 0
      n.storeNote("Same..."); // stores at 1
      n.storeNote("Potato"); // stores at 2
      n.storeNote("Je (ne) suis (pas) desolee"); // stores at 3
      n.storeUrgentNote("I get my permit this weekend"); // stores at 0, moves everything
      n.storeUrgentNote("I NEED FOOD"); // stores at 0, moves everything (urgent note)
      
      System.out.println("Number of note: " + n.numberOfNotes()); // finds number of notes in list
      System.out.println();
      System.out.println("Starting List: ");
      n.listNotes(); // prints list
      System.out.println();
      
      System.out.println("Urgent Notes: ");
      n.listUrgentNotes(); // prints urgent notes only
      System.out.println();
      
      n.demoteNote(3); // demotes a regular note
      n.demoteNote(0); // demotes an urgent note
      n.swapNotes(0); // swaps 0 and 1
      
      System.out.println("Current list:");
      n.listNotes(); // prints new list
      System.out.println();
      
      System.out.println("Current list:");
      n.removeNote(3);
      n.listNotes(); // prints new list
      
      



   
   }
}