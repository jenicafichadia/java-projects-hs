public class TunesTester
 {
   public static void main(String[] args)
    {
     Song s1 = new Song("Yellow", "Cold Play", 2.4);
     Song s2 = new Song("Clocks", "Cold Play", 3.56);
     System.out.println(s2);
     Playlist p = new Playlist("ColdPlayHits");
     if(p.addSong(s1))System.out.println(s1+" added");;
     if(p.addSong(s2))System.out.println(s2+" added");;
     System.out.println( p.totalSongs());
     System.out.println( p.playlistTime());
     if(p.removeSong(s2))System.out.println(s2+" deleted");;
      System.out.println( p.totalSongs());
      p.addSong(s2);
     if( p.isSongInPlaylist("clocks"))// not case-sensative
        System.out.println("clocks is in the playlist");
     else 
      System.out.println("clocks is not in the playlist");
      p.songsByArtist( "Cold Play"); // all info
      p.songsByArtist("Grease Monkey");
      Song s3 = new Song("Around the Sun", "REM", 4.30);
      Playlist favorites = new Playlist("favorites");
      if(favorites.addSong(s3))System.out.println(s3+" Added");;
      if(favorites.addSong(s1))System.out.println(s1+" Added");;
      if(favorites.addSongsFrom(p))System.out.println(p+" Added");;
      favorites.getList(); //getList() returns List<Song> type and toString() in ArrayList class prints the list contents
       
      Song s4 = new Song("Peace Sign", "Kenshi Yonezu", 3.34);
      Song s5 = new Song("Confetti", "Tori Kelly", 3.59);
      Song s7 = new Song("Confetti", "Tori Kelly", 3.59);
      Song s6 = new Song("Hollow", "Tori Kelly", 3.59);
      System.out.println();
      if(p.addSong(s4))System.out.println(s4+" added");;
      if(p.addSong(s5))System.out.println(s5+" added");;
      if(p.addSong(s6))System.out.println(s6+" added");;
      if(p.addSong(s7))System.out.println(s7+" added");;
      p.songsByArtist("Tori Kelly");
      p.songsByArtist("Troye Sivan");
      System.out.println( p.totalSongs() );
      System.out.println( p.playlistTime());
      if( p.isSongInPlaylist("Peace Sign"))// not case-sensative
        System.out.println("Peace Sign is in the playlist");
     else 
      System.out.println("Peace Sign is not in the playlist");
      if( p.isSongInPlaylist("WILD"))// not case-sensative
        System.out.println("WILD is in the playlist");
     else 
      System.out.println("WILD is not in the playlist");
      
      if(favorites.addSongsFrom(p))System.out.println(p+" Added");;
      
     }
   }
