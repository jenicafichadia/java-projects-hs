// Jenica Fichadia and Jennifer Lam pd2
import java.util.ArrayList;
import java.util.Collections;

public class MyClass{
   private ArrayList<String> students;
   
   public MyClass() {
      students = new ArrayList<String>();
   }
   
   public int size(){
      return students.size();
   }
   
   public static void printList(ArrayList<String> x){
      Collections.sort(x);
      int count = 1;
      for(String s: x){
         System.out.println(count + ") " + s);
         count++;
      }
   }
   
   public static void removeCh (ArrayList<String> x, char ch){
      for (int i = 0; i<x.size(); i++){
         if (x.get(i).startsWith(ch+"")){
            x.remove(i);
            i--;
         }
      }
   }
   
   public static void addArray(ArrayList<String> x, String[] names){
      for(String s : names){
         x.add(s);
      }
   }
   
   public static void replaceName(ArrayList<String> x, String oldOne, String newOne){
      int i = 0; 
      for(String s : x){
         if(s.equals(oldOne)){
            x.set(i, newOne);
         }
         i++;
      }
   }
   
   public static void removeDup (ArrayList<String> x){      
      for(int i=0; i<x.size(); i++){
         for (int j=i+1; j<x.size(); j++){
            if(x.get(i).compareToIgnoreCase(x.get(j))>0){
               String temp = x.get(i);
               x.set(i, x.get(j));
               x.set(j, temp);
            }
         }
      }

      for(int i=1; i<x.size(); i++){
         if(x.get(i).equals(x.get(i-1))){
            x.remove(i-1);
            i--;
         }
      }
   } 
   
   public static void main(String[] args) {
      MyClass s = new MyClass();
      ArrayList<String> t = new ArrayList<String>();
      String[] names = {"Arsalan", "John", "Alice", "Hyunsun", "Ehsan", "Karam", "Billy", "Connor", "Key", "Teddy", "Brian", "Sam", "Owen", "Shayann", "Bob", "Eric", "Dianna", "Mia", "Eamon", "Jean", "Tony", "Dilon", "Andrew", "JeongIn", 
                        "Vincent", "Harshini", "Alex", "Nick", "Kiwon", "Camille", "Alexa", "Nick", "Lekha", "Scott", "Summer", "Katherine", "Charlie", "James", "Josh", "Ben", "Chris" ,"James", "Matt", "Michelle", "Edwin", "Albert"};
      s.addArray(t, names);
      s.printList(t);
      System.out.println();
      
      s.removeDup(t);
      s.printList(t);
      System.out.println();
      
      s.removeCh(t, 'A');
      s.printList(t);
      System.out.println();
      
      s.replaceName(t, "Gia", "Jenica"); 
      s.replaceName(t, "Bob", "Gia");
      s.printList(t);
      System.out.println();
   }
   
   
   
   
   
   
   
   
   
   
   
   
     
   
   
}