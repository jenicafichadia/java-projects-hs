// Jencia Fichadia and Jennifer Lam
import java.util.*;

public class DNA{
  public static void main(String[] args){
   Scanner input = new Scanner(System.in);
   final int MISMATCH = 2;
   
   System.out.print("Enter DNA1: ");
   String dna1 = input.nextLine();
   System.out.print("Enter DNA2: ");
   String dna2 = input.nextLine();
   
   String[] d1 = dna1.split(" ");
   String[] d2 = dna2.split(" ");
   String[] bd1 = new String[d1.length];
   
   for (int b = 0; b < d1.length; b++){
      bd1[b] = d1[d1.length-1-b];
   }
   int a = Math.min(d1.length, d2.length);
   int i = 0;
   int fmm = 0;
   int bmm = 0;
   if(d1.length-d2.length>0 || d2.length-d1.length>0){
      System.out.println("DNA1 does not match with DNA2");
   }
   else{
      while (a!=i){
         if (!(d1[i].equals(d2[i]))){
            fmm++;
         }
         if (!(d2[i].equals(bd1[i]))){
            bmm++;
         }
         i++;
      }
      

      System.out.println("DNA1 matches DNA2 forward with " + fmm + " mismatches");
      System.out.println("DNA1 matches DNA2 backward with " + bmm + " mismatches");
      
      if (fmm<=MISMATCH || bmm<= MISMATCH){
         System.out.println("DNA1 matches with DNA2");
      }
      else{
         System.out.println("DNA1 does not match with DNA2");
      } 
}
  
  
  
}  
  
  
  
}
   