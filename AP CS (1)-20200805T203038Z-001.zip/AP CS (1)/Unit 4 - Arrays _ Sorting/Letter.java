// Jenica Fichadia and Jennifer Lam pd2

public class Letter {
   private String sender;
   private String message;
   
   public Letter(String name, String text){
      sender = name;
      message = text;
   }
   
   public String getSender(){
      return sender;
   }

   public String getMsg(){
      return message;
   }
   public String toString(){
      return "From: " + sender + "\nMessage: " + message;
   }
}
