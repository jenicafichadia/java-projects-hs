// Jenica Fichadia and Jennifer Lam pd 2

public class SortLab{
   public static void main(String[] args){
      int [] array = {2, 7, 31, 1, 5, 95, 64, 67, 70, 17}; // 10 numbers of your  choice
      System.out.print("Original: ");
      printArray(array);
      System.out.println();
         
      System.out.print("Scrambled: ");
      scramble(array);
      printArray(array);
      System.out.println();
         
      System.out.print("Insertion Sort: ");
      insertionSort(array);
      printArray(array);
      System.out.println();
      System.out.print("Scrambled: ");
      scramble(array);
      printArray(array);
      System.out.println();
         
      System.out.print("Selection Sort: ");
      selectionSort(array);
      printArray(array);
      System.out.println();
         
      System.out.print("Scrambled: ");
      scramble(array);
      printArray(array);
      System.out.println();
         
      System.out.print("Merge Sort: ");
      mergeSort(array, 0, array.length-1);
      printArray(array);
      System.out.println();
      
      System.out.print("Scrambled: ");
      scramble(array);
      printArray(array);
      System.out.println();
            
      System.out.print("Bubble Sort: ");
      bubbleSort(array);
      printArray(array);
      System.out.println();
   }
  
   public static void insertionSort(int[] array){
      int j, index, key;
      for (j = 1; j < array.length; j++){
         key = array[j];
         for (index = j - 1; (index >= 0) && (array[index] > key); index--){
            array[index + 1] = array[index];
         }
         array[index + 1] = key; // insert key into proper position
      }
   }  
  
   public static void selectionSort(int[] array){
      int index, j, temp, moves, min, minIndex;
      moves = 0;
      for (index = 0; index < array.length; index++){
         min = array[index];
         minIndex = index;
         for (j = index + 1; j < array.length; j++)
            if (array[j] < min){
               min = array[j];
               minIndex = j;
            }
      
         if (min < array[index]){
            temp = array[index];
            array[index] = min;
            array[minIndex] = temp;
            moves++;
         }
      }
   
   
   }  
  
   public static void mergeSort(int[] array, int lo, int n){
      int low = lo;
      int high = n;
      if (low >= high) {
         return;
      }
      int middle = (low + high) / 2;
      mergeSort(array, low, middle);
      mergeSort(array, middle + 1, high);
      int end_low = middle;
      int start_high = middle + 1;
      while ((lo <= end_low) && (start_high <= high)) {
         if (array[low] < array[start_high]) {
            low++;
         } 
         else {
            int Temp = array[start_high];
            for (int k = start_high- 1; k >= low; k--) {
               array[k+1] = array[k];
            }
            array[low] = Temp;
            low++;
            end_low++;
            start_high++;
         }
      }
   }
     
   public static void printArray(int[] array){
      for(int i=0; i<array.length; i++){
         System.out.print(array[i] + " ");
      }     
   }
     
   public static void scramble(int[] array){
      for(int i=0; i<array.length; i++){
         int x = (int)(Math.random()*array.length);
         int y = array[i];
         array[i] = array[x];
         array[x] = y;
      }
     
   }
   
   public static void bubbleSort(int[] array){
   int temp;
   int moves=-1;
   while(moves!=0){
      moves = 0;
      for(int i=0; i<array.length-1; i++){
         if(array[i]>array[i+1]){
            temp = array[i];
            array[i] = array[i+1];
            array[i+1]=temp;
            moves++;
         }
      }
   }
   
   
}


  
  
}