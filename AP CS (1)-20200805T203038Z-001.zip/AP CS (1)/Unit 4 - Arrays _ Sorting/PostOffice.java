// Jenica Fichadia and Jennifer Lam pd 2

public class PostOffice {
   /**The array of Letters used to represent the post office boxes. */
   private Letter pobox[];
  
   public PostOffice(int size){
      pobox = new Letter[size];
   }
   /**Places a Letter in the post office box with the specified number and returns true.
    * Returns false if that post office box already contains a Letter or if there
    * exists no post office box with that number.
    * @param mail The Letter to be placed in the post office box.
    * @param boxNum The number of the post office box in which the Letter will be placed.
    */
   
   public boolean placeLetter(Letter mail, int boxNum){
      if(boxNum>=0 && boxNum<pobox.length && pobox[boxNum]==(null)){
         pobox[boxNum] = mail;
         return true;
      }
      return false;
   }
   
   public String retrieveMsg(int boxNum){
      if (!(boxNum>=0 && boxNum<pobox.length)){
         return "Box does not exist!";
      }
      else if((pobox[boxNum]==(null))){
         return "Empty!";
      }
      return pobox[boxNum].getMsg();
   }
   
   /** Returns the first Letter found that has a sender whose name matches the name
    * passed by the method's argument. Returns null if no Letter with a matching
    * sender is found.
    * @param name The name of the sender whose Letter will be found.
    */
      public Letter findSender(String name){
         boolean tf = false;
         for(int i=0; i<pobox.length; i++){
            if(pobox[i]!=null){
               if(name.equals(pobox[i].getSender()) && tf==false){
                  tf = true;
                  return pobox[i];
               }
            }
         }            
         return null;
   }
 }
