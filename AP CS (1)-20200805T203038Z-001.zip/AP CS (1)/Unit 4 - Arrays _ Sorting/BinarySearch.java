// Jenica Fichadia and Jennifer Lam pd2
import java.util.Arrays;

public class BinarySearch{
   final int LENGTH = 15;
   private String[] pizza = new String [LENGTH];
   
   public BinarySearch(String[] pizza){
      this.pizza = pizza;
      Arrays.sort(this.pizza);
   }
   
   public int binarySearch(String[] words, String key){
      int min = 0;
      int max = words.length-1;
      int mid = 0;
      String currString;
      int a = 0;
      sortArray(words); 
      int z = -1; 
      while(!(words[mid].equals(key)) && a!=LENGTH){
         mid = (min+max) / 2;
         currString = words[mid];
         
         if(currString.compareToIgnoreCase(key)== 0){
            z = mid;
         }
         else if (currString.compareToIgnoreCase(key)>0){
            max = mid-1;            
         }
         else if(currString.compareToIgnoreCase(key)<0){
            min = mid+1;
         }  
         else {
         }  
         a++;    
      }
      return z;
   }
   
   
   public boolean addTopping(String top){
      sortArray(pizza);
      boolean t = false;
      int index = 0;
      boolean b = false;
      for (int a = 0; a < LENGTH; a++){
         if(pizza[a].equals("zzz")&&b==false){
            index = a;
            b = true;
         }
      }
      for (int i = index; i < LENGTH; i++){
         if (pizza[i].equals("zzz")&&t==false){
            pizza[i] = top;
            t = true;
         }
      }
      sortArray(pizza);
                 
      return t;
   }
   
   public static void sortArray(String[] array){      
      for(int i=0; i<array.length; i++){
         for (int j=i+1; j<array.length; j++){
            if(array[i].compareToIgnoreCase(array[j])>0){
               String temp = array[i];
               array[i] = array[j];
               array[j] = temp;
            }
         
         }
      }

   }
   
   public String printToppings(){
      sortArray(pizza);
      //int i=0;
      String p = "";
      for (int i = 0; i < LENGTH; i++){
         if (!(pizza[i].equals("zzz"))){
            p+=pizza[i] + "\n";
         }
      }
      /*while(!(pizza[i].equals("zzz")) || i!=LENGTH){
         p += pizza[i] + "\n";
         i++;
      }*/
      return p;
   }








}