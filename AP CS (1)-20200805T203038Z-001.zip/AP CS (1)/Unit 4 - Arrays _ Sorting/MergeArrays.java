// Jenica Fichadia and Jennifer Lam pd2
import java.util.Arrays;

public class MergeArrays{
   final static int MAX = 100;
   final static int MIN = -100;
   
   public static void main(String[] args){
      int n1 = (int)((Math.random()*5)+1);
      int n2 = (int)((Math.random()*5)+1);
      int[] a = new int[n1];
      int[] b = new int[n2];
      for (int i = 0; i < n1; i++){//first array
         int x = (int)(Math.random()*(MAX-MIN))+MIN;
         a[i] = x;
      }
      for (int j = 0; j < n2; j++){//second array
         int y = (int)(Math.random()*(MAX-MIN))+MIN;
         b[j] = y;
      }
      Arrays.sort(a);
      Arrays.sort(b);
      System.out.println("Array 1: " + Arrays.toString(a));
      System.out.println("Array 2: " + Arrays.toString(b));
      System.out.println("Merged: " + Arrays.toString(merge(a, b)));
   }
   public static int[] merge(int[] A, int[] B){
      int[] c = new int[A.length+B.length];
      int n = 0;
      for(int i = 0; i < c.length; i++){
         if (i<A.length){
            c[i] = A[i];
         }
         else{
            c[i] = B[n];
            n++;
         }
      }
      for(int k=0; k<c.length; k++){
         for (int l=k+1; l<c.length; l++){
            if(c[k]>c[l]){
               int temp = c[k];
               c[k] = c[l];
               c[l] = temp;
            }
         
         }
      }
      return c;
      
   }
   



}