// Jenica Fichadia and Jennifer Lam pd2
import java.util.Scanner;
public class MyListTester{
   public static void main(String[] args){
      Scanner input = new Scanner(System.in);
      
      String[] pizzazz = {"frog legs", "sausage", "zzz", "zzz", "extra cheese", "peppers", "onion", "mushrooms", "ham", "ground beef", "anchovies", "zzz", "zzz", "zzz", "zzz"};
      BinarySearch yummy = new BinarySearch(pizzazz);
      System.out.println( yummy.printToppings() + "\n");
      System.out.println( yummy.addTopping("bacon"));
      System.out.println( yummy.addTopping("pineapple"));;
      System.out.println( yummy.addTopping("peas"));
      System.out.println( yummy.addTopping("chocolate"));
      System.out.println( yummy.addTopping("potato"));
      System.out.println( yummy.addTopping("fish"));
      System.out.println( yummy.addTopping("pepperoni"));
      System.out.println("\n" + yummy.printToppings());
      
      for(int i=1; i<=4; i++){
         System.out.print("Give a topping: ");
         String top = input.next();
         System.out.println( "The index is " + yummy.binarySearch(pizzazz, top) );
      }     
      
   
   }
}