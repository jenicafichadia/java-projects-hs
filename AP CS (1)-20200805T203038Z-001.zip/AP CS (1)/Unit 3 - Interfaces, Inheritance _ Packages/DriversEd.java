public class DriversEd implements Gradable {
   private String name;
   private int points;
   
   public DriversEd (String n){
      name = n;
      points = 100;
   }
   
   public void deductPoints(int num){  
      points-=num;
   }
   
   public String getName(){
      return name;
   }
   
   public boolean isPassing(){
     return (points>=85);
   
   }
   
   public double getPercent(){
      return points;
   }
   
}