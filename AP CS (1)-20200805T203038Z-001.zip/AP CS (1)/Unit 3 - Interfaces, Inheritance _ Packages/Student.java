
public class Student implements Gradable {
   private String name;
   private double score;
   private int numScore;
   
   public Student(String n){
      name = n;
      numScore = 0;
   }  
      
   public void addTestScore (double score){
      this.score=score+this.score;
      numScore++;
   }
      
   public String getName() {
      return name;
   }
      
   public double getPercent(){
      double scoreP=this.score/numScore;         
      return scoreP;
   }
   
   public boolean isPassing(){
      return (this.getPercent()>=60);
   }
   
}
