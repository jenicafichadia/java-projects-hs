// Jenica Fichadia and Jennifer Lam pd2

public interface Gradable{
   double getPercent();
   boolean isPassing();
}